import React, { useState } from 'react';
import { useCareNest } from '../../context/CareNestContext';
import { Beneficiary } from '../../types';
import {
  Utensils,
  AlertTriangle,
  MapPin,
  CheckCircle2,
  Phone,
  Clock,
  Heart,
  HelpCircle,
  ShieldCheck,
  Languages,
} from 'lucide-react';

export const ElderlyPortal: React.FC = () => {
  const {
    beneficiaries,
    markMealCompleted,
    requestFood,
    shareLocation,
    stopSharingLocation,
    triggerEmergency,
    addToast,
  } = useCareNest();

  // Current simulated elderly beneficiary (e.g. Kamala Devi or select from dropdown for testing)
  const [selectedBenId, setSelectedBenId] = useState(beneficiaries[0]?.id || '');
  const [isEmergencyConfirmOpen, setIsEmergencyConfirmOpen] = useState(false);
  const [isNeedFoodOpen, setIsNeedFoodOpen] = useState(false);
  const [foodNeedNote, setFoodNeedNote] = useState('Daily Rice & Vegetables Pack');
  const [useTamil, setUseTamil] = useState(true);

  const beneficiary = beneficiaries.find((b) => b.id === selectedBenId) || beneficiaries[0];

  if (!beneficiary) {
    return <div className="p-8 text-center">Loading beneficiary...</div>;
  }

  const handleToggleMeal = (mealType: 'breakfast' | 'lunch' | 'dinner') => {
    markMealCompleted(beneficiary.id, mealType);
  };

  const handleShareLocation = () => {
    if (beneficiary.locationSharingActive) {
      stopSharingLocation(beneficiary.id);
    } else {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            shareLocation(beneficiary.id, {
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
            });
          },
          () => {
            shareLocation(beneficiary.id, beneficiary.coords);
          }
        );
      } else {
        shareLocation(beneficiary.id, beneficiary.coords);
      }
    }
  };

  const handleEmergencyClick = () => {
    setIsEmergencyConfirmOpen(true);
  };

  const handleEmergencyConfirm = () => {
    triggerEmergency(beneficiary.id, beneficiary.coords, 'Emergency SOS button pressed on elderly portal');
    setIsEmergencyConfirmOpen(false);
  };

  const handleNeedFoodSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    requestFood(
      beneficiary.id,
      foodNeedNote,
      'Standard 1-Day Pack',
      'Requested via Elderly Quick Portal',
      'Urgent',
      beneficiary.coords
    );
    setIsNeedFoodOpen(false);
  };

  return (
    <div className="max-w-xl mx-auto space-y-6 pb-20">
      {/* Switch Persona / Language toggle bar */}
      <div className="bg-white p-4 rounded-3xl border border-stone-200 shadow-2xs flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">Elderly Account:</span>
          <select
            value={selectedBenId}
            onChange={(e) => setSelectedBenId(e.target.value)}
            className="text-xs font-bold text-slate-800 bg-stone-50 border border-stone-200 rounded-xl px-2.5 py-1.5"
          >
            {beneficiaries.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.area})
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={() => setUseTamil(!useTamil)}
          className="px-3 py-1.5 rounded-xl border border-stone-200 bg-stone-50 hover:bg-stone-100 text-xs font-bold text-teal-800 flex items-center gap-1.5 transition-colors"
        >
          <Languages className="w-3.5 h-3.5" />
          <span>{useTamil ? 'தமிழ் / English' : 'English Only'}</span>
        </button>
      </div>

      {/* Greeting Banner */}
      <div className="bg-gradient-to-br from-teal-900 via-teal-800 to-teal-950 text-white p-6 sm:p-8 rounded-3xl shadow-md text-center space-y-2">
        <div className="w-20 h-20 rounded-full bg-teal-100 text-teal-950 mx-auto overflow-hidden border-4 border-white/80 shadow-md flex items-center justify-center text-2xl font-bold">
          {beneficiary.profilePhotoUrl ? (
            <img
              src={beneficiary.profilePhotoUrl}
              alt={beneficiary.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <span>{beneficiary.name.slice(0, 2).toUpperCase()}</span>
          )}
        </div>
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight">{beneficiary.name}</h1>
        <p className="text-xs sm:text-sm text-teal-100/90 font-medium">
          {useTamil ? 'கும்பகோணம் சமூக நல உதவி மையம்' : 'Kumbakonam Community Care Platform'}
        </p>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-xs text-teal-200 font-mono">
          <MapPin className="w-3.5 h-3.5" /> {beneficiary.area} · {beneficiary.code}
        </div>
      </div>

      {/* 1. Large Action Button: 🚨 EMERGENCY HELP (Priority High Contrast) */}
      <button
        onClick={handleEmergencyClick}
        className="w-full py-6 px-6 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white rounded-3xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-4 text-left group active:scale-98 emergency-pulse"
      >
        <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
          <AlertTriangle className="w-10 h-10 text-white" />
        </div>
        <div>
          <span className="text-xl sm:text-2xl font-black block tracking-tight">
            {useTamil ? 'அவசர உதவி (EMERGENCY HELP)' : 'EMERGENCY HELP (SOS)'}
          </span>
          <span className="text-xs sm:text-sm text-red-100 block mt-0.5">
            {useTamil
              ? 'உடனடி உணவு & மருத்துவ உதவிக்காக அழுத்தவும்'
              : 'Press for immediate rapid volunteer & medical dispatch'}
          </span>
        </div>
      </button>

      {/* 2. Primary Action Buttons Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* I Need Food */}
        <button
          onClick={() => setIsNeedFoodOpen(true)}
          className="p-6 bg-amber-500 hover:bg-amber-600 text-white rounded-3xl shadow-md hover:shadow-lg transition-all flex flex-col items-center text-center space-y-2 group active:scale-98"
        >
          <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Utensils className="w-9 h-9 text-white" />
          </div>
          <span className="text-lg font-black tracking-tight">
            {useTamil ? 'உணவு தேவை' : 'I Need Food'}
          </span>
          <span className="text-xs text-amber-100">
            {useTamil ? 'மளிகை அல்லது சமைத்த உணவு கேட்க' : 'Request food provisions or cooked meal'}
          </span>
        </button>

        {/* Share My Location */}
        <button
          onClick={handleShareLocation}
          className={`p-6 rounded-3xl shadow-md hover:shadow-lg transition-all flex flex-col items-center text-center space-y-2 group active:scale-98 ${
            beneficiary.locationSharingActive
              ? 'bg-emerald-600 text-white hover:bg-emerald-700 ring-4 ring-emerald-300'
              : 'bg-teal-800 text-white hover:bg-teal-900'
          }`}
        >
          <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
            <MapPin className="w-9 h-9 text-white" />
          </div>
          <span className="text-lg font-black tracking-tight">
            {beneficiary.locationSharingActive
              ? useTamil
                ? 'இருப்பிடம் பகிரப்படுகிறது ✅'
                : 'Location Shared ✅'
              : useTamil
              ? 'இருப்பிடத்தை பகிரவும்'
              : 'Share My Location'}
          </span>
          <span className="text-xs text-teal-100">
            {beneficiary.locationSharingActive
              ? useTamil
                ? 'தன்னார்வலர் வழிகாட்டுதலுக்கு இயங்குகிறது'
                : 'Live GPS beacon active for volunteer'
              : useTamil
              ? 'தன்னார்வலர் உங்களை எளிதில் வந்தடைய'
              : 'Help volunteer find your home faster'}
          </span>
        </button>
      </div>

      {/* 3. Meal Completed Tracker Card (High Contrast Big Buttons) */}
      <div className="bg-white rounded-3xl border-2 border-stone-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <div>
            <h3 className="text-base font-extrabold text-slate-900">
              {useTamil ? 'இன்றைய உணவு நிலை' : "Today's Meals"}
            </h3>
            <p className="text-xs text-slate-500">
              {useTamil ? 'சாப்பிட்டதை பதிவு செய்ய தொடவும்' : 'Tap after having your meal'}
            </p>
          </div>
          <Clock className="w-5 h-5 text-teal-700" />
        </div>

        <div className="grid grid-cols-3 gap-3">
          {(['breakfast', 'lunch', 'dinner'] as const).map((m) => {
            const isDone = beneficiary.mealStatus[m] === 'completed';
            const tamilLabel = m === 'breakfast' ? 'காலை' : m === 'lunch' ? 'மதியம்' : 'இரவு';

            return (
              <button
                key={m}
                onClick={() => handleToggleMeal(m)}
                className={`py-4 px-2 rounded-2xl border-2 text-center transition-all flex flex-col items-center justify-center space-y-1.5 ${
                  isDone
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold'
                    : 'bg-stone-50 border-stone-300 text-slate-700 hover:border-teal-500'
                }`}
              >
                <span className="text-2xl">{isDone ? '✅' : '⏳'}</span>
                <span className="text-xs font-black uppercase tracking-wider">{m}</span>
                {useTamil && <span className="text-[11px] font-semibold">{tamilLabel}</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. My Food Inventory Card */}
      <div className="bg-white rounded-3xl border-2 border-stone-200 p-6 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Utensils className="w-5 h-5 text-teal-700" />
            <h3 className="text-base font-extrabold text-slate-900">
              {useTamil ? 'என் உணவு இருப்பு' : 'My Food Stock'}
            </h3>
          </div>
          <span
            className={`text-xs font-black px-3 py-1 rounded-xl ${
              beneficiary.foodStatus === 'critical'
                ? 'bg-red-100 text-red-700 font-mono'
                : beneficiary.foodStatus === 'low'
                ? 'bg-amber-100 text-amber-800 font-mono'
                : 'bg-emerald-100 text-emerald-800 font-mono'
            }`}
          >
            {beneficiary.currentStockKg} kg / {beneficiary.requiredStockKg} kg
          </span>
        </div>

        <p className="text-xs text-slate-600 bg-stone-50 p-3 rounded-2xl border border-stone-100">
          <span className="font-bold text-slate-800">
            {useTamil ? 'வழங்கப்படும் உணவு வகை: ' : 'Assigned Provisions: '}
          </span>
          {beneficiary.foodRequirement}
        </p>
      </div>

      {/* 5. Contact NGO Help Button */}
      <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-xs flex items-center justify-between gap-4">
        <div>
          <h4 className="text-base font-extrabold text-slate-900">
            {useTamil ? 'அமைப்பை தொடர்பு கொள்ள' : 'Contact Care Team'}
          </h4>
          <p className="text-xs text-slate-500">
            {useTamil ? 'கும்பகோணம் சேவை மையம் (24/7)' : 'Kumbakonam Central Helpline (24/7)'}
          </p>
          <span className="text-sm font-black font-mono text-teal-800 mt-1 block">
            +91 94432 12345
          </span>
        </div>

        <a
          href="tel:+919443212345"
          className="py-3 px-5 bg-teal-800 hover:bg-teal-900 text-white rounded-2xl font-bold text-xs flex items-center gap-2 shadow-sm transition-colors"
        >
          <Phone className="w-4 h-4" />
          <span>{useTamil ? 'அழைக்க' : 'Call'}</span>
        </a>
      </div>

      {/* Confirmation Modal for Emergency */}
      {isEmergencyConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl border-4 border-red-500 animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-full bg-red-100 text-red-700 flex items-center justify-center mx-auto text-3xl emergency-pulse">
              🚨
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900">
                {useTamil ? 'அவசர உதவி வேண்டுமா?' : 'Confirm Emergency Alert?'}
              </h3>
              <p className="text-xs text-slate-600 mt-1">
                {useTamil
                  ? 'கும்பகோணம் சேவை மைய தன்னார்வலர்கள் உடனடியாக உங்கள் இருப்பிடத்திற்கு புறப்படுவார்கள்.'
                  : 'Volunteers and emergency care will be immediately dispatched to your location.'}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => setIsEmergencyConfirmOpen(false)}
                className="py-3 px-4 bg-stone-100 hover:bg-stone-200 text-slate-700 font-bold rounded-2xl text-xs"
              >
                {useTamil ? 'வேண்டாம்' : 'Cancel'}
              </button>
              <button
                onClick={handleEmergencyConfirm}
                className="py-3 px-4 bg-red-600 hover:bg-red-700 text-white font-black rounded-2xl text-xs shadow-md"
              >
                {useTamil ? 'ஆம், உதவி தேவை' : 'YES, SEND HELP'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Need Food Modal */}
      {isNeedFoodOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in">
            <div className="flex items-center gap-2 mb-2">
              <Utensils className="w-5 h-5 text-amber-600" />
              <h3 className="text-lg font-black text-slate-900">
                {useTamil ? 'உணவு உதவி கோரிக்கை' : 'Request Food Assistance'}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              {useTamil
                ? 'உங்கள் கோரிக்கை உடனடியாக தன்னார்வலருக்கு அனுப்பப்படும்.'
                : 'Your request will be dispatched to available volunteers in Kumbakonam.'}
            </p>

            <form onSubmit={handleNeedFoodSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  {useTamil ? 'தேவையான உணவு விவரம்' : 'Food Package Required'}
                </label>
                <input
                  type="text"
                  required
                  value={foodNeedNote}
                  onChange={(e) => setFoodNeedNote(e.target.value)}
                  className="w-full p-3 bg-stone-50 border border-stone-200 rounded-2xl text-sm text-slate-800 font-medium"
                />
              </div>

              <div className="p-3 bg-teal-50 rounded-2xl border border-teal-200 text-xs text-teal-900 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-teal-700 shrink-0" />
                <span>
                  Delivery Address: <strong>{beneficiary.area}</strong> ({beneficiary.address})
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNeedFoodOpen(false)}
                  className="py-3 px-4 bg-stone-100 hover:bg-stone-200 text-slate-700 rounded-2xl font-bold"
                >
                  {useTamil ? 'ரத்து' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="py-3 px-5 bg-teal-800 hover:bg-teal-900 text-white rounded-2xl font-black shadow-md"
                >
                  {useTamil ? 'கோரிக்கையை அனுப்புக' : 'Submit Food Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
