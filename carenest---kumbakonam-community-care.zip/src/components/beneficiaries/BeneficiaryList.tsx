import React, { useState } from 'react';
import { useCareNest } from '../../context/CareNestContext';
import { Beneficiary, AreaName, FoodStatus } from '../../types';
import {
  Search,
  Filter,
  Plus,
  Phone,
  MapPin,
  Utensils,
  AlertTriangle,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
} from 'lucide-react';

interface BeneficiaryListProps {
  onSelectBeneficiary: (b: Beneficiary) => void;
  onRequestFood: (b: Beneficiary) => void;
}

export const BeneficiaryList: React.FC<BeneficiaryListProps> = ({
  onSelectBeneficiary,
  onRequestFood,
}) => {
  const {
    beneficiaries,
    selectedAreaFilter,
    setSelectedAreaFilter,
    selectedStatusFilter,
    setSelectedStatusFilter,
  } = useCareNest();

  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New beneficiary form state
  const [newName, setNewName] = useState('');
  const [newAge, setNewAge] = useState('70');
  const [newGender, setNewGender] = useState<'Female' | 'Male' | 'Other'>('Female');
  const [newArea, setNewArea] = useState<AreaName>('Kumbakonam Town');
  const [newAddress, setNewAddress] = useState('');
  const [newPhone, setNewPhone] = useState('+91 94432 ');
  const [newRequirement, setNewRequirement] = useState('Ponni Boiled Rice & Vegetables');

  const filtered = beneficiaries.filter((b) => {
    // Area filter
    if (selectedAreaFilter !== 'All' && b.area !== selectedAreaFilter) return false;

    // Status filter
    if (selectedStatusFilter === 'Critical' && b.foodStatus !== 'critical') return false;
    if (selectedStatusFilter === 'Low' && b.foodStatus !== 'low') return false;
    if (selectedStatusFilter === 'Emergency' && b.foodStatus !== 'emergency') return false;
    if (selectedStatusFilter === 'Sufficient' && b.foodStatus !== 'sufficient') return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = b.name.toLowerCase().includes(q);
      const matchCode = b.code.toLowerCase().includes(q);
      const matchArea = b.area.toLowerCase().includes(q);
      return matchName || matchCode || matchArea;
    }

    return true;
  });

  const areas: Array<AreaName | 'All'> = [
    'All',
    'Kumbakonam Town',
    'Darasuram',
    'Swamimalai',
    'Patteeswaram',
    'Nachiyarkoil',
    'Thiruvidaimarudur',
    'Valangaiman',
    'Koranattukaruppur',
    'Ullur',
    'Cholapuram',
  ];

  const handleRegisterBeneficiary = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newAddress.trim()) return;

    // Quick add to list through state/context or alert
    setIsAddModalOpen(false);
    // Reset inputs
    setNewName('');
    setNewAddress('');
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Search Bar */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Beneficiary Directory
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Registered elderly and vulnerable residents of Kumbakonam & surrounding taluks
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-2 bg-teal-800 hover:bg-teal-900 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              Register Beneficiary
            </button>
          </div>
        </div>

        {/* Search & Filters */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-2">
          {/* Search Box */}
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by name, ID (e.g. CN-KUM-001) or area..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-slate-800 placeholder:text-slate-400 focus:outline-teal-700"
            />
          </div>

          {/* Area Filter */}
          <div className="md:col-span-3">
            <select
              value={selectedAreaFilter}
              onChange={(e) => setSelectedAreaFilter(e.target.value as any)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-slate-700 font-medium focus:outline-teal-700"
            >
              {areas.map((a) => (
                <option key={a} value={a}>
                  {a === 'All' ? 'All Areas' : a}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="md:col-span-3">
            <select
              value={selectedStatusFilter}
              onChange={(e) => setSelectedStatusFilter(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-slate-700 font-medium focus:outline-teal-700"
            >
              <option value="All">All Food Statuses</option>
              <option value="Critical">🔴 Critical Stock (≤25%)</option>
              <option value="Low">🟡 Low Stock (≤50%)</option>
              <option value="Emergency">🚨 Emergency Alert</option>
              <option value="Sufficient">🟢 Sufficient</option>
            </select>
          </div>
        </div>
      </div>

      {/* Beneficiaries Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((b) => {
          const stockPercent = Math.round((b.currentStockKg / b.requiredStockKg) * 100);

          return (
            <div
              key={b.id}
              className="bg-white rounded-2xl border border-stone-200 p-5 shadow-2xs hover:shadow-md hover:border-teal-500 transition-all flex flex-col justify-between space-y-4"
            >
              {/* Card Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-900 font-bold text-sm flex items-center justify-center border-2 border-stone-100 overflow-hidden shrink-0">
                    {b.profilePhotoUrl ? (
                      <img src={b.profilePhotoUrl} alt={b.name} className="w-full h-full object-cover" />
                    ) : (
                      <span>{b.name.slice(0, 2).toUpperCase()}</span>
                    )}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 leading-snug">{b.name}</h3>
                    <p className="text-xs text-slate-500">
                      {b.age} yrs · <span className="font-mono text-slate-600">{b.code}</span>
                    </p>
                    <p className="text-[11px] text-teal-800 font-medium flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-teal-700" />
                      {b.area}
                    </p>
                  </div>
                </div>

                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                    b.foodStatus === 'emergency'
                      ? 'bg-purple-100 text-purple-700 emergency-pulse'
                      : b.foodStatus === 'critical'
                      ? 'bg-red-100 text-red-700'
                      : b.foodStatus === 'low'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {b.foodStatus.toUpperCase()}
                </span>
              </div>

              {/* Stock Meter */}
              <div className="space-y-1.5 bg-stone-50 p-3 rounded-xl border border-stone-100 text-xs">
                <div className="flex justify-between items-center text-slate-600">
                  <span className="font-medium">Provisions Remaining</span>
                  <span className="font-mono font-bold text-slate-900">
                    {b.currentStockKg} kg / {b.requiredStockKg} kg
                  </span>
                </div>
                <div className="w-full h-2 bg-stone-200 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      stockPercent <= 25
                        ? 'bg-red-500'
                        : stockPercent <= 50
                        ? 'bg-amber-500'
                        : 'bg-emerald-500'
                    }`}
                    style={{ width: `${Math.min(stockPercent, 100)}%` }}
                  />
                </div>
                <div className="text-[11px] text-slate-500 truncate pt-0.5">
                  <span className="font-semibold text-slate-600">Need:</span> {b.foodRequirement}
                </div>
              </div>

              {/* Environment & Meals Badges */}
              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-stone-100">
                <span className="font-mono">
                  🌡️ {b.ambientTemp}°C · 💧 {b.ambientHumidity}%
                </span>
                <span>
                  Meals: {b.mealStatus.breakfast === 'completed' ? 'B ✅' : 'B ⏳'}{' '}
                  {b.mealStatus.lunch === 'completed' ? 'L ✅' : 'L ⏳'}{' '}
                  {b.mealStatus.dinner === 'completed' ? 'D ✅' : 'D ⏳'}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => onSelectBeneficiary(b)}
                  className="flex-1 py-2 px-3 bg-stone-100 hover:bg-stone-200 text-slate-800 font-semibold text-xs rounded-xl text-center transition-colors"
                >
                  Full Profile
                </button>
                <button
                  onClick={() => onRequestFood(b)}
                  className="py-2 px-3 bg-teal-800 hover:bg-teal-900 text-white font-semibold text-xs rounded-xl transition-colors flex items-center gap-1"
                >
                  <Utensils className="w-3.5 h-3.5" /> Request
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="py-16 text-center bg-white rounded-3xl border border-stone-200 p-8 space-y-2">
          <p className="text-base font-bold text-slate-700">No beneficiaries match your criteria</p>
          <p className="text-xs text-slate-400">
            Try adjusting search terms or resetting the area and status filters.
          </p>
        </div>
      )}

      {/* Add Beneficiary Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in">
            <h3 className="text-lg font-bold text-slate-900">Register New Beneficiary</h3>
            <p className="text-xs text-slate-500 mt-1">
              Add an elderly or vulnerable individual in the Kumbakonam service network.
            </p>

            <form onSubmit={handleRegisterBeneficiary} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Kasthuri Ammal"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Age</label>
                  <input
                    type="number"
                    value={newAge}
                    onChange={(e) => setNewAge(e.target.value)}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Area</label>
                  <select
                    value={newArea}
                    onChange={(e) => setNewArea(e.target.value as AreaName)}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    {areas
                      .filter((a) => a !== 'All')
                      .map((a) => (
                        <option key={a} value={a}>
                          {a}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Street Address</label>
                <input
                  type="text"
                  required
                  placeholder="Street / Landmark near temple / bus stop"
                  value={newAddress}
                  onChange={(e) => setNewAddress(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Food Requirement</label>
                <input
                  type="text"
                  value={newRequirement}
                  onChange={(e) => setNewRequirement(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="py-2 px-4 bg-stone-100 hover:bg-stone-200 text-slate-700 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="py-2 px-4 bg-teal-800 hover:bg-teal-900 text-white rounded-xl font-bold"
                >
                  Register Beneficiary
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
