import React, { useState } from 'react';
import { useCareNest } from '../../context/CareNestContext';
import { Beneficiary, MealStatusType } from '../../types';
import { PhotoUploadModal } from '../common/PhotoUploadModal';
import {
  X,
  Phone,
  AlertTriangle,
  Utensils,
  MapPin,
  Camera,
  CheckCircle2,
  Clock,
  Thermometer,
  Droplets,
  Calendar,
  Heart,
  Share2,
  User,
  ShieldCheck,
} from 'lucide-react';

interface BeneficiaryProfileModalProps {
  beneficiary: Beneficiary | null;
  isOpen: boolean;
  onClose: () => void;
  onRequestFood: (beneficiary: Beneficiary) => void;
}

export const BeneficiaryProfileModal: React.FC<BeneficiaryProfileModalProps> = ({
  beneficiary,
  isOpen,
  onClose,
  onRequestFood,
}) => {
  const {
    uploadBeneficiaryPhoto,
    markMealCompleted,
    triggerEmergency,
    shareLocation,
    stopSharingLocation,
  } = useCareNest();

  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'history' | 'health'>('overview');

  if (!isOpen || !beneficiary) return null;

  const stockPercent = Math.round(
    (beneficiary.currentStockKg / beneficiary.requiredStockKg) * 100
  );

  const handlePhotoUploaded = (photoUrl: string) => {
    uploadBeneficiaryPhoto(beneficiary.id, photoUrl);
  };

  const handleToggleMeal = (mealType: 'breakfast' | 'lunch' | 'dinner') => {
    markMealCompleted(beneficiary.id, mealType);
  };

  const handleLocationToggle = () => {
    if (beneficiary.locationSharingActive) {
      stopSharingLocation(beneficiary.id);
    } else {
      // Simulate or request browser location
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            shareLocation(beneficiary.id, {
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
            });
          },
          () => {
            shareLocation(beneficiary.id, beneficiary.coords);
          }
        );
      } else {
        shareLocation(beneficiary.id, beneficiary.coords);
      }
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
        <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-stone-200 my-8 animate-in fade-in zoom-in-95 duration-200">
          {/* Header Banner */}
          <div className="relative bg-gradient-to-r from-teal-900 to-teal-800 text-white p-6 pb-12">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-white/70 hover:text-white rounded-full hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-teal-200 text-xs font-semibold mb-1">
              <ShieldCheck className="w-4 h-4 text-teal-300" />
              <span>Verified Beneficiary Profile · CareNest Kumbakonam</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight">{beneficiary.name}</h2>
            <p className="text-xs text-teal-100/80">
              {beneficiary.age} years old · {beneficiary.gender} · {beneficiary.code}
            </p>
          </div>

          {/* Profile Card Overlay Header */}
          <div className="px-6 -mt-8 relative z-10 flex flex-wrap items-end justify-between gap-4">
            <div className="flex items-end gap-3.5">
              <div className="relative group">
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-teal-100 border-4 border-white shadow-md overflow-hidden flex items-center justify-center text-teal-900 font-bold text-2xl">
                  {beneficiary.profilePhotoUrl ? (
                    <img
                      src={beneficiary.profilePhotoUrl}
                      alt={beneficiary.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span>{beneficiary.name.slice(0, 2).toUpperCase()}</span>
                  )}
                </div>
                <button
                  onClick={() => setIsPhotoModalOpen(true)}
                  className="absolute bottom-1 right-1 p-1.5 bg-slate-900 text-white rounded-lg shadow-sm hover:bg-teal-700 transition-colors"
                  title="Upload / Change Profile Photo"
                >
                  <Camera className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="pb-1">
                <span
                  className={`text-xs font-bold px-2.5 py-1 rounded-lg ${
                    beneficiary.foodStatus === 'emergency'
                      ? 'bg-purple-100 text-purple-700 border border-purple-200'
                      : beneficiary.foodStatus === 'critical'
                      ? 'bg-red-100 text-red-700 border border-red-200'
                      : beneficiary.foodStatus === 'low'
                      ? 'bg-amber-100 text-amber-800 border border-amber-200'
                      : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                  }`}
                >
                  {beneficiary.foodStatus.toUpperCase()} STATUS
                </span>
                <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  {beneficiary.area}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pb-1">
              <a
                href={`tel:${beneficiary.phone}`}
                className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Phone className="w-4 h-4" /> Call Phone
              </a>
              <button
                onClick={() => onRequestFood(beneficiary)}
                className="px-4 py-2 bg-teal-800 hover:bg-teal-900 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Utensils className="w-4 h-4" /> Request Food
              </button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex border-b border-stone-200 px-6 mt-4 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-3 px-4 border-b-2 transition-colors ${
                activeTab === 'overview'
                  ? 'border-teal-700 text-teal-900 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Overview & Food Status
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`py-3 px-4 border-b-2 transition-colors ${
                activeTab === 'history'
                  ? 'border-teal-700 text-teal-900 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Assistance History ({beneficiary.assistanceHistory.length})
            </button>
            <button
              onClick={() => setActiveTab('health')}
              className={`py-3 px-4 border-b-2 transition-colors ${
                activeTab === 'health'
                  ? 'border-teal-700 text-teal-900 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Health & Dietary Notes
            </button>
          </div>

          {/* Modal Tab Body */}
          <div className="p-6 space-y-5 max-h-[60vh] overflow-y-auto">
            {activeTab === 'overview' && (
              <div className="space-y-5">
                {/* 1. Food Inventory & Requirement Section */}
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      🍚 Food Stock & Need
                    </span>
                    <span className="text-xs font-mono font-bold text-slate-900">
                      {beneficiary.currentStockKg} kg / {beneficiary.requiredStockKg} kg ({stockPercent}%)
                    </span>
                  </div>

                  <div className="w-full h-3 bg-stone-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        stockPercent <= 25
                          ? 'bg-red-500'
                          : stockPercent <= 50
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(stockPercent, 100)}%` }}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                    <div>
                      <span className="text-slate-400 block">Required Food:</span>
                      <span className="font-semibold text-slate-800">
                        {beneficiary.foodRequirement}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Dietary Restrictions:</span>
                      <span className="font-semibold text-slate-800">
                        {beneficiary.dietaryNotes || 'Standard diet'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* 2. Today's Meal Status */}
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      🍽️ Meal Status Today
                    </span>
                    <span className="text-[11px] text-slate-500">Click to record completion</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    {(['breakfast', 'lunch', 'dinner'] as const).map((meal) => {
                      const isDone = beneficiary.mealStatus[meal] === 'completed';
                      return (
                        <button
                          key={meal}
                          onClick={() => handleToggleMeal(meal)}
                          className={`p-2.5 rounded-xl border text-center transition-all ${
                            isDone
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                              : 'bg-white border-stone-200 text-slate-600 hover:border-teal-400'
                          }`}
                        >
                          <div className="text-xs font-bold capitalize">{meal}</div>
                          <div className="text-[11px] mt-0.5 font-semibold">
                            {isDone ? '✅ Completed' : '⏳ Pending'}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 3. Environment & Location Details */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Environmental telemetry */}
                  <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                      🌡️ Ambient Environment
                    </span>
                    <div className="flex items-center gap-4 text-xs font-mono pt-1">
                      <div className="flex items-center gap-1.5 text-slate-700">
                        <Thermometer className="w-4 h-4 text-red-500" />
                        <span className="font-bold">{beneficiary.ambientTemp}°C</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-700">
                        <Droplets className="w-4 h-4 text-blue-500" />
                        <span className="font-bold">{beneficiary.ambientHumidity}% Humidity</span>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400 block">
                      Monitored during latest care delivery check
                    </span>
                  </div>

                  {/* Location & GPS Sharing */}
                  <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                        📍 GPS Location
                      </span>
                      <button
                        onClick={handleLocationToggle}
                        className={`text-[11px] font-bold px-2 py-0.5 rounded-md transition-colors ${
                          beneficiary.locationSharingActive
                            ? 'bg-teal-100 text-teal-800 hover:bg-teal-200'
                            : 'bg-stone-200 text-slate-700 hover:bg-stone-300'
                        }`}
                      >
                        {beneficiary.locationSharingActive ? 'Active' : 'Turn On'}
                      </button>
                    </div>
                    <p className="text-xs text-slate-600 leading-snug line-clamp-2">
                      {beneficiary.address}
                    </p>
                    <div className="text-[10px] font-mono text-slate-500">
                      Coordinates: {beneficiary.coords.lat.toFixed(4)},{' '}
                      {beneficiary.coords.lng.toFixed(4)}
                    </div>
                  </div>
                </div>

                {/* 4. Contact & Caregiver */}
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Primary Phone:</span>
                    <span className="font-semibold text-slate-800 font-mono">
                      {beneficiary.phone}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Emergency Contact:</span>
                    <span className="font-semibold text-slate-800 font-mono">
                      {beneficiary.emergencyContact} ({beneficiary.emergencyContactRelation})
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Registered Date:</span>
                    <span className="text-slate-700">{beneficiary.registeredDate}</span>
                  </div>
                </div>

                {/* Quick SOS Trigger */}
                <div className="pt-1">
                  <button
                    onClick={() => {
                      triggerEmergency(beneficiary.id, beneficiary.coords, 'Triggered from NGO profile review');
                      onClose();
                    }}
                    className="w-full py-2.5 px-4 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                  >
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                    Raise Priority Emergency SOS Alert for {beneficiary.name}
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'history' && (
              <div className="space-y-3">
                {beneficiary.assistanceHistory.length > 0 ? (
                  beneficiary.assistanceHistory.map((h) => (
                    <div
                      key={h.id}
                      className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800">{h.type}</span>
                        <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-semibold text-[10px]">
                          {h.status}
                        </span>
                      </div>
                      <p className="text-slate-600 text-[11px]">{h.notes}</p>
                      <span className="text-[10px] text-slate-400 font-mono block pt-0.5">
                        Delivered on {h.date}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="py-8 text-center text-slate-400 text-xs">
                    No prior assistance history recorded yet.
                  </div>
                )}
              </div>
            )}

            {activeTab === 'health' && (
              <div className="space-y-4 text-xs">
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-1.5">
                  <h4 className="font-bold text-slate-800">Health & Mobility Status</h4>
                  <p className="text-slate-600 leading-relaxed">{beneficiary.healthNotes}</p>
                </div>

                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-1.5">
                  <h4 className="font-bold text-slate-800">Dietary Preferences & Allergies</h4>
                  <p className="text-slate-600 leading-relaxed">{beneficiary.dietaryNotes}</p>
                </div>

                <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-amber-800 space-y-1 text-[11px]">
                  <span className="font-bold block">Privacy & Dignity Protection</span>
                  <p>
                    Beneficiary medical and dietary details are protected. Seed data shown is
                    fictional and used solely for NGO operations demonstration.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Photo Upload Modal */}
      <PhotoUploadModal
        isOpen={isPhotoModalOpen}
        onClose={() => setIsPhotoModalOpen(false)}
        onPhotoSelected={handlePhotoUploaded}
        title={`Update Photo for ${beneficiary.name}`}
        description="Capture or upload photo with informed consent."
        consentNotice="Ensure beneficiary or designated caregiver consent is granted before capturing or updating photo."
      />
    </>
  );
};
