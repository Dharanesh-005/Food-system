import React from 'react';
import { useCareNest } from '../../context/CareNestContext';
import {
  BarChart3,
  TrendingUp,
  Award,
  Users,
  Utensils,
  MapPin,
  Clock,
  Heart,
  Download,
  Calendar,
  ShieldCheck,
  IndianRupee,
} from 'lucide-react';

export const NGOAnalytics: React.FC = () => {
  const { metrics, beneficiaries, deliveries, orders, addToast } = useCareNest();

  const handleExportReport = () => {
    addToast(
      'Report Exported',
      'CareNest SDG 2 Kumbakonam Monthly Impact Report exported to CSV format.',
      'success'
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-md bg-teal-50 text-teal-800 border border-teal-200 inline-flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-teal-700" />
              United Nations SDG 2 Impact Tracking
            </span>
          </div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            Kumbakonam Food Security & Care Analytics
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Operational performance, zero-hunger metrics & community market reinvestment ratios
          </p>
        </div>

        <button
          onClick={handleExportReport}
          className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-slate-800 rounded-xl text-xs font-bold transition-colors flex items-center gap-2"
        >
          <Download className="w-4 h-4 text-slate-600" />
          Export Impact Report (CSV)
        </button>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold text-slate-600">Zero Hunger Ratio</span>
            <Utensils className="w-4 h-4 text-teal-700" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {Math.round((metrics.sufficientCount / metrics.totalBeneficiaries) * 100)}%
          </div>
          <p className="text-[11px] text-emerald-600 font-medium">
            Beneficiaries currently with secure food supply
          </p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold text-slate-600">Avg Delivery Speed</span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">6.4 mins</div>
          <p className="text-[11px] text-slate-500 font-medium">
            From emergency trigger to volunteer arrival
          </p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold text-slate-600">Market Surplus Reinvested</span>
            <IndianRupee className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            ₹{Math.round(metrics.totalMarketRevenue * 0.75).toLocaleString('en-IN')}
          </div>
          <p className="text-[11px] text-emerald-600 font-medium">
            75% revenue pledged to senior food assistance
          </p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold text-slate-600">Total Supported Meals</span>
            <Heart className="w-4 h-4 text-red-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {metrics.mealsSupportedCount}
          </div>
          <p className="text-[11px] text-teal-700 font-medium">
            Delivered across Kumbakonam & taluks
          </p>
        </div>
      </div>

      {/* Two-Column Analytics: Area Distribution & Food Status Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Area Distribution Chart (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            Beneficiary Coverage & Stock Health by Area
          </h3>

          <div className="space-y-3 pt-2">
            {Object.entries(metrics.areaStats).map(([area, stats]) => {
              const total = stats.total;
              const criticalPct = Math.round((stats.critical / total) * 100);
              const lowPct = Math.round((stats.low / total) * 100);
              const sufficientPct = 100 - criticalPct - lowPct;

              return (
                <div key={area} className="space-y-1 text-xs">
                  <div className="flex justify-between items-center text-slate-700 font-medium">
                    <span className="font-bold">{area}</span>
                    <span className="font-mono text-slate-500">
                      {total} senior(s) · {stats.critical > 0 ? `🔴 ${stats.critical} Critical` : '🟢 Stable'}
                    </span>
                  </div>

                  <div className="w-full h-3 bg-stone-100 rounded-full flex overflow-hidden">
                    {stats.critical > 0 && (
                      <div
                        style={{ width: `${criticalPct}%` }}
                        className="bg-red-500 h-full"
                        title={`Critical: ${stats.critical}`}
                      />
                    )}
                    {stats.low > 0 && (
                      <div
                        style={{ width: `${lowPct}%` }}
                        className="bg-amber-500 h-full"
                        title={`Low: ${stats.low}`}
                      />
                    )}
                    {stats.sufficient > 0 && (
                      <div
                        style={{ width: `${sufficientPct}%` }}
                        className="bg-emerald-500 h-full"
                        title={`Sufficient: ${stats.sufficient}`}
                      />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Food Status Breakdown (5 cols) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">Regional Food Stock Split</h3>

          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-100 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 font-semibold text-emerald-800">
                <span className="w-3 h-3 rounded-full bg-emerald-500" /> Sufficient (Stock &gt; 50%)
              </span>
              <span className="font-mono font-bold text-slate-800">{metrics.sufficientCount}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 font-semibold text-amber-800">
                <span className="w-3 h-3 rounded-full bg-amber-500" /> Low (Stock 25% - 50%)
              </span>
              <span className="font-mono font-bold text-slate-800">{metrics.lowCount}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 font-semibold text-red-700">
                <span className="w-3 h-3 rounded-full bg-red-500" /> Critical (Stock &lt; 25%)
              </span>
              <span className="font-mono font-bold text-slate-800">{metrics.criticalCount}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 font-semibold text-purple-700">
                <span className="w-3 h-3 rounded-full bg-purple-600" /> Active Emergency SOS
              </span>
              <span className="font-mono font-bold text-slate-800">{metrics.emergencyCount}</span>
            </div>
          </div>

          <div className="p-4 bg-teal-50 rounded-2xl border border-teal-200 text-xs text-teal-900 space-y-1">
            <span className="font-bold block">Secondary Focus: Health & Hygiene</span>
            <p className="leading-relaxed text-[11px]">
              Ambient temperature (avg 29.3°C) and storage humidity (avg 62%) in Kumbakonam are
              continuously audited during each grain handover to prevent mold growth in rice bins.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
