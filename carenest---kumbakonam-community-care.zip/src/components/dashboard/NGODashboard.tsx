import React, { useState } from 'react';
import { useCareNest } from '../../context/CareNestContext';
import { KumbakonamLiveMap } from '../map/KumbakonamLiveMap';
import { Beneficiary, AreaName } from '../../types';
import {
  Users,
  AlertCircle,
  Truck,
  AlertTriangle,
  IndianRupee,
  Utensils,
  MapPin,
  ArrowUpRight,
  Clock,
  ShieldCheck,
  ChevronRight,
  Flame,
  Activity,
  UserCheck,
  PlusCircle,
} from 'lucide-react';

interface NGODashboardProps {
  onOpenBeneficiary: (b: Beneficiary) => void;
  onOpenNewRequest: () => void;
}

export const NGODashboard: React.FC<NGODashboardProps> = ({
  onOpenBeneficiary,
  onOpenNewRequest,
}) => {
  const {
    metrics,
    beneficiaries,
    activityLogs,
    deliveries,
    emergencies,
    selectedAreaFilter,
    setSelectedAreaFilter,
    setSelectedBeneficiaryId,
    setActiveTab,
    assignVolunteerToRequest,
    volunteers,
  } = useCareNest();

  const [assigningRequestId, setAssigningRequestId] = useState<string | null>(null);

  // Filter urgent beneficiaries who need attention (critical or emergency)
  const attentionBeneficiaries = beneficiaries.filter(
    (b) => b.foodStatus === 'critical' || b.foodStatus === 'emergency'
  );

  const activeDeliveriesList = deliveries.filter(
    (d) => d.status === 'Out for Delivery' || d.status === 'Assigned' || d.status === 'Accepted'
  );

  const areas: AreaName[] = [
    'Kumbakonam Town',
    'Darasuram',
    'Swamimalai',
    'Patteeswaram',
    'Nachiyarkoil',
    'Thiruvidaimarudur',
    'Valangaiman',
    'Koranattukaruppur',
    'Ullur',
    'Cholapuram',
  ];

  return (
    <div className="space-y-8 pb-16">
      {/* 1. Header & Location Badge */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-stone-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-teal-50 text-teal-800 border border-teal-200/60 inline-flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-teal-700" />
              Kumbakonam & Surrounding Taluks, Tamil Nadu
            </span>
            <span className="text-xs text-stone-400">·</span>
            <span className="text-xs text-stone-500 font-medium">SDG 2: Zero Hunger</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
            Good morning, Care Team 👋
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Kumbakonam Community Assistance Overview · Find those who need food. Reach them faster.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setActiveTab('emergency')}
            className="px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl text-xs font-bold transition-colors flex items-center gap-2"
          >
            <AlertTriangle className="w-4 h-4 text-red-600" />
            Emergency Center ({metrics.emergencyCount})
          </button>
          <button
            onClick={onOpenNewRequest}
            className="px-4 py-2.5 bg-teal-800 hover:bg-teal-900 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors flex items-center gap-1.5"
          >
            <PlusCircle className="w-4 h-4" />
            + New Assistance Request
          </button>
        </div>
      </div>

      {/* 2. Top KPI Cards (Calculated dynamically) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* Card 1: Beneficiaries */}
        <div
          onClick={() => setActiveTab('beneficiaries')}
          className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs hover:border-teal-400 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold text-slate-600">Beneficiaries</span>
            <Users className="w-4 h-4 text-teal-700 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {metrics.totalBeneficiaries}+
          </div>
          <div className="text-[11px] text-slate-500 mt-1">10 Taluk zones registered</div>
        </div>

        {/* Card 2: Need Attention */}
        <div
          onClick={() => setActiveTab('beneficiaries')}
          className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs hover:border-red-400 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold text-red-600">Need Attention</span>
            <AlertCircle className="w-4 h-4 text-red-500 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-extrabold text-red-600 font-mono tabular-nums">
            {metrics.needAttentionCount}
          </div>
          <div className="text-[11px] text-red-500/80 mt-1">Stock critical or low</div>
        </div>

        {/* Card 3: Active Deliveries */}
        <div
          onClick={() => setActiveTab('deliveries')}
          className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs hover:border-blue-400 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold text-slate-600">Active Deliveries</span>
            <Truck className="w-4 h-4 text-blue-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-extrabold text-blue-600 font-mono tabular-nums">
            {metrics.activeDeliveriesCount}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Live en-route & assigned</div>
        </div>

        {/* Card 4: Emergency Alerts */}
        <div
          onClick={() => setActiveTab('emergency')}
          className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs hover:border-purple-400 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold text-purple-700">Emergency Alerts</span>
            <AlertTriangle className="w-4 h-4 text-purple-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-extrabold text-purple-700 font-mono tabular-nums">
            {metrics.emergencyCount}
          </div>
          <div className="text-[11px] text-purple-600/80 mt-1">Immediate response</div>
        </div>

        {/* Card 5: Market Sales */}
        <div
          onClick={() => setActiveTab('market')}
          className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs hover:border-amber-400 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold text-slate-600">Market Sales</span>
            <IndianRupee className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            ₹{metrics.totalMarketRevenue.toLocaleString('en-IN')}
          </div>
          <div className="text-[11px] text-emerald-600 mt-1">Community revenue</div>
        </div>

        {/* Card 6: Meals Supported */}
        <div
          onClick={() => setActiveTab('food-monitoring')}
          className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs hover:border-teal-400 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold text-slate-600">Meals Supported</span>
            <Utensils className="w-4 h-4 text-teal-700 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl font-extrabold text-teal-800 font-mono tabular-nums">
            {metrics.mealsSupportedCount}
          </div>
          <div className="text-[11px] text-teal-700/80 mt-1">Zero hunger initiative</div>
        </div>
      </div>

      {/* 3. Main Centerpiece: Live Assistance Map */}
      <div>
        <KumbakonamLiveMap onSelectBeneficiary={onOpenBeneficiary} />
      </div>

      {/* 4. Two-Column Working Section: Community Assistance by Area + Live Community Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Community Assistance by Area */}
        <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Community Assistance by Area
              </h3>
              <p className="text-xs text-slate-500">
                Click any area to filter map markers and dispatch priority
              </p>
            </div>
            {selectedAreaFilter !== 'All' && (
              <button
                onClick={() => setSelectedAreaFilter('All')}
                className="text-xs text-teal-700 hover:underline font-semibold"
              >
                Reset Filter (Show All)
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            {areas.map((area) => {
              const stats = metrics.areaStats[area] || { critical: 0, low: 0, sufficient: 0, total: 0 };
              const isSelected = selectedAreaFilter === area;

              return (
                <div
                  key={area}
                  onClick={() => setSelectedAreaFilter(isSelected ? 'All' : area)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'border-teal-600 bg-teal-50/50 shadow-xs ring-1 ring-teal-600'
                      : 'border-stone-200 hover:border-stone-300 bg-stone-50/40 hover:bg-stone-50'
                  }`}
                >
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">{area}</h4>
                    <div className="flex items-center gap-2 mt-1 text-[11px]">
                      {stats.critical > 0 && (
                        <span className="text-red-600 font-semibold font-mono">
                          🔴 {stats.critical} Critical
                        </span>
                      )}
                      {stats.low > 0 && (
                        <span className="text-amber-600 font-semibold font-mono">
                          🟡 {stats.low} Low
                        </span>
                      )}
                      {stats.critical === 0 && stats.low === 0 && (
                        <span className="text-emerald-600 font-semibold font-mono">
                          🟢 {stats.sufficient} Sufficient
                        </span>
                      )}
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-stone-400 shrink-0" />
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (5 cols): Live Community Activity Feed */}
        <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-teal-500 animate-ping"></span>
              <h3 className="text-base font-bold text-slate-900">
                Live Community Activity
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">Real-time Stream</span>
          </div>

          <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
            {activityLogs.slice(0, 7).map((log) => {
              const getDot = () => {
                if (log.severity === 'danger') return '🔴';
                if (log.severity === 'warning') return '🟡';
                if (log.severity === 'success') return '✅';
                return '📍';
              };

              return (
                <div
                  key={log.id}
                  className="flex items-start gap-2.5 p-2.5 rounded-xl hover:bg-stone-50 transition-colors border border-stone-100"
                >
                  <span className="text-sm shrink-0 mt-0.5">{getDot()}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-slate-800 font-medium leading-snug">
                      {log.message}
                    </p>
                    <span className="text-[10px] text-slate-400 font-mono mt-1 block">
                      {log.timestamp}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 5. Needs Attention (Actionable Beneficiaries List) */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Needs Attention ({attentionBeneficiaries.length} vulnerable seniors)
            </h3>
            <p className="text-xs text-slate-500">
              Stock has dropped below threshold or emergency alert is pending
            </p>
          </div>
          <button
            onClick={() => setActiveTab('beneficiaries')}
            className="text-xs text-teal-800 font-bold hover:underline"
          >
            View All 15+ Beneficiaries →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-1">
          {attentionBeneficiaries.slice(0, 6).map((ben) => {
            const stockPercent = Math.round((ben.currentStockKg / ben.requiredStockKg) * 100);

            return (
              <div
                key={ben.id}
                className="p-4 rounded-2xl border border-stone-200 hover:border-teal-500 hover:shadow-sm transition-all bg-white flex flex-col justify-between space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs shrink-0 overflow-hidden">
                      {ben.profilePhotoUrl ? (
                        <img
                          src={ben.profilePhotoUrl}
                          alt={ben.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span>{ben.name.slice(0, 2).toUpperCase()}</span>
                      )}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 leading-tight">
                        {ben.name}
                      </h4>
                      <span className="text-xs text-slate-500">
                        {ben.age} years · {ben.area}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                      ben.foodStatus === 'emergency'
                        ? 'bg-purple-100 text-purple-700 animate-pulse'
                        : 'bg-red-100 text-red-700'
                    }`}
                  >
                    {ben.foodStatus === 'emergency' ? '🚨 Emergency' : '🔴 Critical'}
                  </span>
                </div>

                {/* Stock Gauge */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500 font-medium">Food Stock</span>
                    <span className="font-mono font-bold text-slate-800">
                      {ben.currentStockKg} kg / {ben.requiredStockKg} kg ({stockPercent}%)
                    </span>
                  </div>
                  <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        stockPercent <= 25 ? 'bg-red-500' : 'bg-amber-500'
                      }`}
                      style={{ width: `${Math.min(stockPercent, 100)}%` }}
                    />
                  </div>
                </div>

                {/* Dietary Requirement */}
                <div className="text-[11px] text-slate-600 bg-stone-50 p-2 rounded-xl">
                  <span className="font-semibold text-slate-700">Need:</span> {ben.foodRequirement}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => {
                      setSelectedBeneficiaryId(ben.id);
                      onOpenBeneficiary(ben);
                    }}
                    className="flex-1 py-1.5 px-3 bg-stone-100 hover:bg-stone-200 text-slate-800 font-semibold text-xs rounded-xl text-center transition-colors"
                  >
                    View Details
                  </button>
                  <button
                    onClick={() => {
                      // Quick assign volunteer or jump to deliveries
                      setActiveTab('deliveries');
                    }}
                    className="py-1.5 px-3 bg-teal-800 hover:bg-teal-900 text-white font-semibold text-xs rounded-xl transition-colors"
                  >
                    Dispatch Food
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
