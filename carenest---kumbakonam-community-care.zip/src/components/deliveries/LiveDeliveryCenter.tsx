import React, { useState } from 'react';
import { useCareNest } from '../../context/CareNestContext';
import { Delivery, DeliveryStatus, Volunteer } from '../../types';
import { PhotoUploadModal } from '../common/PhotoUploadModal';
import {
  Truck,
  MapPin,
  Clock,
  CheckCircle2,
  Navigation,
  Phone,
  Camera,
  AlertCircle,
  User,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';

export const LiveDeliveryCenter: React.FC = () => {
  const {
    deliveries,
    volunteers,
    requests,
    updateDeliveryStatus,
    assignVolunteerToRequest,
    addToast,
  } = useCareNest();

  const [selectedDelivery, setSelectedDelivery] = useState<Delivery | null>(deliveries[0] || null);
  const [isProofModalOpen, setIsProofModalOpen] = useState(false);
  const [activeDeliveryForProof, setActiveDeliveryForProof] = useState<string | null>(null);

  const activeDeliveries = deliveries.filter((d) => d.status !== 'Delivered');
  const completedDeliveries = deliveries.filter((d) => d.status === 'Delivered');
  const unassignedRequests = requests.filter((r) => r.status === 'Requested' || r.status === 'Reviewed');

  const handleAdvanceStatus = (delivery: Delivery) => {
    if (delivery.status === 'Assigned') {
      updateDeliveryStatus(delivery.id, 'Accepted');
    } else if (delivery.status === 'Accepted') {
      updateDeliveryStatus(delivery.id, 'Out for Delivery');
    } else if (delivery.status === 'Out for Delivery') {
      updateDeliveryStatus(delivery.id, 'Arrived');
    } else if (delivery.status === 'Arrived') {
      // Require delivery proof photo
      setActiveDeliveryForProof(delivery.id);
      setIsProofModalOpen(true);
    }
  };

  const handleProofUploaded = (photoUrl: string) => {
    if (activeDeliveryForProof) {
      updateDeliveryStatus(activeDeliveryForProof, 'Delivered', photoUrl);
      setIsProofModalOpen(false);
      setActiveDeliveryForProof(null);
    }
  };

  const currentDisplay = selectedDelivery || deliveries[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 inline-flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-blue-600" />
              Volunteer Field Fleet
            </span>
          </div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            Live Delivery Tracking & Volunteer Dispatch
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time GPS routing, status progression & delivery photo proof verification
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="px-3 py-1.5 rounded-xl bg-blue-50 text-blue-800 border border-blue-200">
            <span className="font-bold">{activeDeliveries.length}</span> Active Runs
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200">
            <span className="font-bold">{completedDeliveries.length}</span> Completed Today
          </div>
        </div>
      </div>

      {/* Main Delivery Focus Card */}
      {currentDisplay && (
        <div className="bg-white rounded-3xl border border-stone-200 shadow-sm p-6 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-stone-100">
            <div>
              <span className="text-xs font-mono font-bold text-teal-800 uppercase tracking-wider block">
                Tracking Delivery #{currentDisplay.id}
              </span>
              <h3 className="text-lg font-black text-slate-900 mt-0.5">
                Food Assistance to {currentDisplay.beneficiaryName}
              </h3>
              <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {currentDisplay.area} · <span className="font-semibold">{currentDisplay.foodItems}</span>
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-xs text-slate-400 block">Estimated Arrival</span>
                <span className="text-base font-mono font-bold text-slate-900">
                  {currentDisplay.status === 'Delivered'
                    ? 'Delivered'
                    : `~${currentDisplay.etaMinutes} mins (${currentDisplay.distanceKm} km)`}
                </span>
              </div>

              {currentDisplay.status !== 'Delivered' && (
                <button
                  onClick={() => handleAdvanceStatus(currentDisplay)}
                  className="py-2.5 px-4 bg-teal-800 hover:bg-teal-900 text-white rounded-xl text-xs font-bold transition-colors shadow-xs flex items-center gap-1.5"
                >
                  {currentDisplay.status === 'Assigned' && 'Accept Run'}
                  {currentDisplay.status === 'Accepted' && 'Start Delivery 🚚'}
                  {currentDisplay.status === 'Out for Delivery' && 'Mark Arrived 📍'}
                  {currentDisplay.status === 'Arrived' && 'Upload Proof & Complete 📷'}
                </button>
              )}
            </div>
          </div>

          {/* Progress Tracker Bar */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-600 block">
              Dispatch Progression Lifecycle
            </span>
            <div className="grid grid-cols-5 gap-2 text-center text-xs">
              {[
                { label: 'Assigned', step: 1 },
                { label: 'Accepted', step: 2 },
                { label: 'Out for Delivery', step: 3 },
                { label: 'Arrived', step: 4 },
                { label: 'Delivered', step: 5 },
              ].map((s) => {
                const getIsCurrentOrDone = () => {
                  const states: DeliveryStatus[] = [
                    'Assigned',
                    'Accepted',
                    'Out for Delivery',
                    'Arrived',
                    'Delivered',
                  ];
                  const currentIndex = states.indexOf(currentDisplay.status);
                  const stepIndex = states.indexOf(s.label as DeliveryStatus);
                  return stepIndex <= currentIndex;
                };

                const active = getIsCurrentOrDone();

                return (
                  <div key={s.label} className="space-y-1.5">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        active ? 'bg-teal-700' : 'bg-stone-200'
                      }`}
                    />
                    <span
                      className={`text-[11px] block truncate ${
                        active ? 'font-bold text-slate-900' : 'text-slate-400'
                      }`}
                    >
                      {s.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Route & Personnel Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Volunteer info */}
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
                Assigned Volunteer
              </span>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-800 font-bold flex items-center justify-center text-xs">
                  {currentDisplay.volunteerName.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 leading-tight">
                    {currentDisplay.volunteerName}
                  </h4>
                  <a
                    href={`tel:${currentDisplay.volunteerPhone}`}
                    className="text-[11px] text-teal-800 font-semibold hover:underline flex items-center gap-1 mt-0.5"
                  >
                    <Phone className="w-3 h-3" /> {currentDisplay.volunteerPhone}
                  </a>
                </div>
              </div>
            </div>

            {/* Beneficiary info */}
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
                Recipient Beneficiary
              </span>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-800 font-bold flex items-center justify-center text-xs">
                  {currentDisplay.beneficiaryName.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 leading-tight">
                    {currentDisplay.beneficiaryName}
                  </h4>
                  <a
                    href={`tel:${currentDisplay.beneficiaryPhone}`}
                    className="text-[11px] text-teal-800 font-semibold hover:underline flex items-center gap-1 mt-0.5"
                  >
                    <Phone className="w-3 h-3" /> {currentDisplay.beneficiaryPhone}
                  </a>
                </div>
              </div>
            </div>

            {/* Proof Status */}
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
                Proof Verification
              </span>
              {currentDisplay.proofPhotoUrl ? (
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-lg overflow-hidden border border-emerald-300">
                    <img
                      src={currentDisplay.proofPhotoUrl}
                      alt="Proof"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="text-xs">
                    <span className="text-emerald-700 font-bold block">Verified by Photo</span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Completed at {currentDisplay.completedAt || '11:42 AM'}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-slate-500 flex items-center gap-1.5 pt-1">
                  <Camera className="w-4 h-4 text-slate-400" />
                  <span>Photo capture required upon physical arrival</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Deliveries Queue Table */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900">
            All Deliveries in Kumbakonam Network
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            {deliveries.length} total dispatches
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-stone-50 text-slate-500 uppercase font-semibold text-[10px] border-b border-stone-200">
              <tr>
                <th className="py-3 px-3">Run ID</th>
                <th className="py-3 px-3">Beneficiary</th>
                <th className="py-3 px-3">Volunteer</th>
                <th className="py-3 px-3">Area</th>
                <th className="py-3 px-3">Food Items</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {deliveries.map((del) => {
                const isSelected = selectedDelivery?.id === del.id;
                return (
                  <tr
                    key={del.id}
                    onClick={() => setSelectedDelivery(del)}
                    className={`cursor-pointer hover:bg-stone-50 transition-colors ${
                      isSelected ? 'bg-teal-50/50' : ''
                    }`}
                  >
                    <td className="py-3 px-3 font-mono font-bold text-slate-700">{del.id}</td>
                    <td className="py-3 px-3 font-bold text-slate-900">{del.beneficiaryName}</td>
                    <td className="py-3 px-3 text-slate-600">{del.volunteerName}</td>
                    <td className="py-3 px-3 text-slate-600">{del.area}</td>
                    <td className="py-3 px-3 text-slate-700 max-w-xs truncate">{del.foodItems}</td>
                    <td className="py-3 px-3">
                      <span
                        className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                          del.status === 'Delivered'
                            ? 'bg-emerald-100 text-emerald-800'
                            : del.status === 'Out for Delivery'
                            ? 'bg-blue-100 text-blue-800 animate-pulse'
                            : 'bg-stone-100 text-slate-700'
                        }`}
                      >
                        {del.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedDelivery(del);
                        }}
                        className="text-teal-800 hover:underline font-semibold"
                      >
                        Track
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Unassigned Requests & Volunteer Availability */}
      {unassignedRequests.length > 0 && (
        <div className="bg-white rounded-3xl border border-stone-200 shadow-xs p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Pending Assistance Requests Requiring Dispatch
              </h3>
              <p className="text-xs text-slate-500">
                Assign available field volunteers in the respective taluk
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-2 py-1 rounded-md border border-amber-200">
              {unassignedRequests.length} Pending
            </span>
          </div>

          <div className="space-y-3">
            {unassignedRequests.map((req) => (
              <div
                key={req.id}
                className="p-4 bg-stone-50 rounded-2xl border border-stone-200 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{req.beneficiaryName}</span>
                    <span className="text-slate-400">·</span>
                    <span className="font-semibold text-slate-600">{req.area}</span>
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        req.priority === 'Emergency'
                          ? 'bg-red-100 text-red-700'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {req.priority}
                    </span>
                  </div>
                  <p className="text-slate-600 mt-0.5">
                    {req.foodRequired} ({req.quantity})
                  </p>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Requested at {req.requestedAt} · {req.reason}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    id={`vol-select-${req.id}`}
                    className="p-2 bg-white border border-stone-200 rounded-xl text-xs text-slate-700 font-medium"
                    defaultValue=""
                  >
                    <option value="" disabled>
                      Select Volunteer
                    </option>
                    {volunteers.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.serviceArea}) - {v.availability}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={() => {
                      const sel = document.getElementById(
                        `vol-select-${req.id}`
                      ) as HTMLSelectElement;
                      if (sel && sel.value) {
                        assignVolunteerToRequest(req.id, sel.value);
                      } else {
                        addToast('Select Volunteer', 'Please pick an available volunteer first.', 'warning');
                      }
                    }}
                    className="py-2 px-3.5 bg-teal-800 hover:bg-teal-900 text-white rounded-xl font-bold transition-colors shadow-xs whitespace-nowrap"
                  >
                    Assign Run
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Proof Photo Upload Modal */}
      <PhotoUploadModal
        isOpen={isProofModalOpen}
        onClose={() => setIsProofModalOpen(false)}
        onPhotoSelected={handleProofUploaded}
        title="Capture Delivery Proof Photo"
        description="Verify physical handover to the beneficiary or authorized caregiver."
        consentNotice="Delivery photos are securely stored to verify zero-hunger impact and food recipient safety."
      />
    </div>
  );
};
