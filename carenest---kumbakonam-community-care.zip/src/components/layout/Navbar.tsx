import React, { useState } from 'react';
import { useCareNest } from '../../context/CareNestContext';
import { UserRole } from '../../types';
import {
  Heart,
  ShoppingBag,
  Bell,
  AlertTriangle,
  Menu,
  X,
  UserCheck,
  MapPin,
  RefreshCw,
  Home,
  Users,
  Truck,
  Activity,
  BarChart3,
  Store,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    role,
    setRole,
    activeTab,
    setActiveTab,
    cartCount,
    emergencies,
    toasts,
    removeToast,
    resetToDefaults,
  } = useCareNest();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const activeEmergenciesCount = emergencies.filter((e) => e.status !== 'Resolved').length;

  const roles: { id: UserRole; label: string; desc: string }[] = [
    { id: 'admin', label: 'NGO Admin', desc: 'Full system control' },
    { id: 'staff', label: 'NGO Staff', desc: 'Field & coordination' },
    { id: 'volunteer', label: 'Volunteer', desc: 'Delivery routing & proof' },
    { id: 'beneficiary', label: 'Beneficiary', desc: 'Elderly simplified UI' },
    { id: 'customer', label: 'Customer', desc: 'Community Food Market' },
  ];

  const navLinks = [
    { id: 'dashboard', label: 'Overview', icon: Home, roles: ['admin', 'staff'] },
    { id: 'beneficiaries', label: 'Beneficiaries', icon: Users, roles: ['admin', 'staff'] },
    { id: 'deliveries', label: 'Deliveries', icon: Truck, roles: ['admin', 'staff', 'volunteer'] },
    { id: 'food-monitoring', label: 'Food Radar', icon: Activity, roles: ['admin', 'staff'] },
    { id: 'emergency', label: 'Emergency Center', icon: AlertTriangle, roles: ['admin', 'staff'] },
    { id: 'market', label: 'Food Market', icon: Store, roles: ['admin', 'staff', 'customer'] },
    { id: 'analytics', label: 'Analytics', icon: BarChart3, roles: ['admin'] },
  ];

  const visibleLinks = navLinks.filter((l) => l.roles.includes(role));

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
      {/* Top Bar Contract: Zone 1 (Wordmark) - Zone 2 (Nav Links) - Zone 3 (Actions & Role Switcher) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab(role === 'beneficiary' ? 'elderly-portal' : 'dashboard')}
              className="flex items-center gap-2 text-left group"
            >
              <div className="w-9 h-9 rounded-xl bg-teal-800 text-white flex items-center justify-center shadow-xs group-hover:bg-teal-700 transition-colors">
                <span className="text-base font-black">CN</span>
              </div>
              <div>
                <span className="text-lg font-extrabold tracking-tight text-slate-900 leading-none block">
                  CareNest
                </span>
                <span className="text-[10px] text-teal-800 font-semibold tracking-wider uppercase block">
                  Kumbakonam
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Clean text navigation links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-xs font-semibold text-slate-600">
            {role === 'beneficiary' ? (
              <button
                onClick={() => setActiveTab('elderly-portal')}
                className="px-3 py-1.5 rounded-lg bg-teal-50 text-teal-800 font-bold"
              >
                👵 Elderly Simple View
              </button>
            ) : (
              visibleLinks.map((link) => {
                const Icon = link.icon;
                const isActive = activeTab === link.id;
                const isEmergencyLink = link.id === 'emergency' && activeEmergenciesCount > 0;

                return (
                  <button
                    key={link.id}
                    onClick={() => setActiveTab(link.id)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-colors whitespace-nowrap ${
                      isActive
                        ? 'bg-stone-100 text-slate-900 font-bold'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-stone-50'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isEmergencyLink ? 'text-red-600 animate-pulse' : ''}`} />
                    <span>{link.label}</span>
                    {isEmergencyLink && (
                      <span className="w-2 h-2 rounded-full bg-red-600 animate-ping"></span>
                    )}
                  </button>
                );
              })
            )}
          </nav>

          {/* Zone 3: Role Switcher & Action buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick Role Switcher Pill */}
            <div className="relative flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200">
              <UserCheck className="w-3.5 h-3.5 text-stone-500 ml-1.5 hidden sm:inline" />
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="text-xs font-semibold bg-transparent text-slate-800 px-2 py-1 rounded-lg border-0 focus:ring-0 cursor-pointer"
                title="Switch persona role for full platform exploration"
              >
                {roles.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Shopping Cart Button */}
            <button
              onClick={() => setActiveTab('market')}
              className="relative p-2 text-slate-700 hover:text-teal-800 hover:bg-stone-100 rounded-xl transition-colors"
              title="Community Food Market Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-teal-700 text-white rounded-full text-[10px] font-bold flex items-center justify-center shadow-xs">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Emergency SOS Badge */}
            {activeEmergenciesCount > 0 && (
              <button
                onClick={() => setActiveTab('emergency')}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold emergency-pulse transition-colors"
              >
                <AlertTriangle className="w-4 h-4 text-red-600" />
                <span>{activeEmergenciesCount} Emergency</span>
              </button>
            )}

            {/* Notifications Toggle */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 text-slate-700 hover:text-slate-900 hover:bg-stone-100 rounded-xl transition-colors"
                title="Live Notifications"
              >
                <Bell className="w-5 h-5" />
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-stone-200 p-3 z-50 animate-in fade-in zoom-in-95">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-100 px-2">
                    <span className="text-xs font-bold text-slate-800">Recent Alerts & Updates</span>
                    <button
                      onClick={() => setShowNotifications(false)}
                      className="text-xs text-slate-400 hover:text-slate-600"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="max-h-64 overflow-y-auto divide-y divide-stone-50 text-xs py-1">
                    {toasts.length > 0 ? (
                      toasts.map((t) => (
                        <div key={t.id} className="py-2 px-2 hover:bg-stone-50 rounded-lg">
                          <p className="font-semibold text-slate-800">{t.title}</p>
                          <p className="text-slate-500 text-[11px] mt-0.5">{t.message}</p>
                          <span className="text-[10px] text-slate-400 mt-1 block">{t.timestamp}</span>
                        </div>
                      ))
                    ) : (
                      <p className="py-4 text-center text-slate-400">No new notifications</p>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Reset Database button (helpful for testing) */}
            <button
              onClick={resetToDefaults}
              className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-xl transition-colors"
              title="Reset Sample Data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-slate-700 hover:bg-stone-100 rounded-xl"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-stone-200 bg-white px-4 py-3 space-y-1 animate-in slide-in-from-top-2">
          {visibleLinks.map((link) => {
            const Icon = link.icon;
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => {
                  setActiveTab(link.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                  isActive ? 'bg-teal-50 text-teal-900' : 'text-slate-700 hover:bg-stone-50'
                }`}
              >
                <Icon className="w-5 h-5 text-slate-500" />
                <span>{link.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
