import React, { useState } from 'react';
import { useCareNest } from '../../context/CareNestContext';
import { MarketProduct, MarketOrder } from '../../types';
import {
  ShoppingBag,
  Plus,
  Minus,
  Trash2,
  CheckCircle2,
  Heart,
  Truck,
  IndianRupee,
  Sparkles,
  Store,
  ShieldCheck,
  ArrowRight,
  X,
  CreditCard,
} from 'lucide-react';

export const CommunityMarket: React.FC = () => {
  const {
    marketProducts,
    cart,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    cartTotal,
    cartCount,
    createMarketOrder,
    orders,
    role,
    updateOrderStatus,
  } = useCareNest();

  const [activeTab, setActiveTab] = useState<'browse' | 'orders' | 'admin'>('browse');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Checkout form
  const [customerName, setCustomerName] = useState('Anand Raj');
  const [customerPhone, setCustomerPhone] = useState('+91 94432 99881');
  const [deliveryAddress, setDeliveryAddress] = useState('14, Sannadhi Street, Near Sarangapani Temple, Kumbakonam');
  const [deliveryType, setDeliveryType] = useState<'delivery' | 'pickup'>('delivery');
  const [paymentMethod, setPaymentMethod] = useState<'UPI / GPay' | 'Cash on Delivery' | 'Card'>('UPI / GPay');
  const [confirmedOrder, setConfirmedOrder] = useState<MarketOrder | null>(null);

  const categories = ['All', 'Prepared Meals', 'Ration Supplies', 'Breakfast', 'Pantry Essentials'];

  const filteredProducts = marketProducts.filter((p) => {
    if (selectedCategory !== 'All' && p.category !== selectedCategory) return false;
    return true;
  });

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    const order = createMarketOrder({
      customerName,
      customerPhone,
      deliveryAddress,
      deliveryType,
      paymentMethod,
    });

    setConfirmedOrder(order);
    setIsCheckoutOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-teal-800 to-emerald-900 text-white p-6 sm:p-8 rounded-3xl shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold px-2.5 py-1 rounded-md bg-white/20 text-white backdrop-blur-xs inline-flex items-center gap-1.5">
                <Store className="w-3.5 h-3.5" />
                Social Enterprise Initiative
              </span>
              <span className="text-xs text-teal-200">Kumbakonam NGO Kitchen</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              CareNest Community Food Market
            </h1>
            <p className="text-xs sm:text-sm text-teal-100 max-w-2xl mt-1 leading-relaxed">
              Order fresh, authentic Thanjavur-style meals and grain rations. 100% of community
              surplus directly subsidizes free daily food distribution to vulnerable elderly seniors.
            </p>
          </div>

          {/* Impact Meter */}
          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 text-xs space-y-1">
            <span className="text-teal-200 font-semibold block">Community Impact Meter</span>
            <div className="text-2xl font-black font-mono">126+ Meals Funded</div>
            <p className="text-[11px] text-teal-200/90">
              Every ₹40 order provides 1 nutritious hot meal to a senior
            </p>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex flex-wrap items-center justify-between pt-2 border-t border-white/15 text-xs font-bold gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('browse')}
              className={`px-4 py-2 rounded-xl transition-all ${
                activeTab === 'browse'
                  ? 'bg-white text-teal-950 shadow-sm'
                  : 'text-white/80 hover:bg-white/10'
              }`}
            >
              Browse Food Menu
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`px-4 py-2 rounded-xl transition-all ${
                activeTab === 'orders'
                  ? 'bg-white text-teal-950 shadow-sm'
                  : 'text-white/80 hover:bg-white/10'
              }`}
            >
              Order History ({orders.length})
            </button>
            {(role === 'admin' || role === 'staff') && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`px-4 py-2 rounded-xl transition-all ${
                  activeTab === 'admin'
                    ? 'bg-white text-teal-950 shadow-sm'
                    : 'text-white/80 hover:bg-white/10'
                }`}
              >
                Market Order Operations
              </button>
            )}
          </div>

          {cartCount > 0 && (
            <button
              onClick={() => setIsCheckoutOpen(true)}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-500 text-slate-950 rounded-xl font-bold flex items-center gap-2 shadow-md transition-transform hover:scale-105"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>
                Cart ({cartCount}) · ₹{cartTotal}
              </span>
            </button>
          )}
        </div>
      </div>

      {/* Main Browse Catalog View */}
      {activeTab === 'browse' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Products Column (8 or 12 cols) */}
          <div className={`${cart.length > 0 ? 'lg:col-span-8' : 'lg:col-span-12'} space-y-4`}>
            {/* Category Filter Pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-xl font-semibold whitespace-nowrap transition-colors ${
                    selectedCategory === cat
                      ? 'bg-teal-800 text-white'
                      : 'bg-white border border-stone-200 text-slate-700 hover:bg-stone-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Products Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredProducts.map((prod) => {
                const inCart = cart.find((c) => c.product.id === prod.id);

                return (
                  <div
                    key={prod.id}
                    className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
                  >
                    <div className="relative aspect-4/3 bg-stone-100 overflow-hidden">
                      <img
                        src={prod.imageUrl}
                        alt={prod.name}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-2.5 right-2.5">
                        <span className="px-2 py-0.5 rounded-md bg-white/95 backdrop-blur-xs font-bold text-xs text-slate-900 shadow-xs">
                          ₹{prod.price}
                        </span>
                      </div>
                      <div className="absolute bottom-2 left-2">
                        <span className="px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-xs font-semibold text-[10px] text-white">
                          {prod.category}
                        </span>
                      </div>
                    </div>

                    <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
                      <div>
                        <h3 className="text-sm font-bold text-slate-900 leading-tight">
                          {prod.name}
                        </h3>
                        <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                          {prod.description}
                        </p>
                      </div>

                      <div className="space-y-2 pt-2 border-t border-stone-100">
                        {/* Social Impact Note */}
                        <div className="flex items-start gap-1.5 text-[11px] text-emerald-800 bg-emerald-50 p-2 rounded-xl">
                          <Heart className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{prod.socialImpactNote}</span>
                        </div>

                        {/* Add to Cart button */}
                        <div className="flex items-center justify-between pt-1">
                          <span className="text-xs text-slate-400 font-mono">
                            Stock: {prod.availableStock}
                          </span>

                          {inCart ? (
                            <div className="flex items-center gap-2 bg-teal-50 border border-teal-200 rounded-xl p-1">
                              <button
                                onClick={() =>
                                  updateCartQuantity(prod.id, inCart.quantity - 1)
                                }
                                className="p-1 text-teal-800 hover:bg-teal-100 rounded-lg transition-colors"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="text-xs font-bold text-teal-900 px-1 font-mono">
                                {inCart.quantity}
                              </span>
                              <button
                                onClick={() =>
                                  updateCartQuantity(prod.id, inCart.quantity + 1)
                                }
                                className="p-1 text-teal-800 hover:bg-teal-100 rounded-lg transition-colors"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => addToCart(prod, 1)}
                              className="py-1.5 px-3 bg-teal-800 hover:bg-teal-900 text-white rounded-xl text-xs font-bold transition-colors shadow-xs flex items-center gap-1"
                            >
                              <Plus className="w-3.5 h-3.5" /> Add
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Cart Sidebar Column (4 cols when items exist) */}
          {cart.length > 0 && (
            <div className="lg:col-span-4 bg-white rounded-3xl border border-stone-200 p-6 shadow-xs space-y-4 h-fit sticky top-20">
              <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-teal-800" />
                  <h3 className="text-base font-bold text-slate-900">Your Market Cart</h3>
                </div>
                <button
                  onClick={clearCart}
                  className="text-xs text-slate-400 hover:text-red-600 transition-colors"
                >
                  Clear
                </button>
              </div>

              <div className="divide-y divide-stone-100 max-h-64 overflow-y-auto pr-1">
                {cart.map((item) => (
                  <div key={item.product.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                    <div className="min-w-0">
                      <h4 className="font-bold text-slate-900 truncate">{item.product.name}</h4>
                      <span className="text-slate-500 font-mono">
                        ₹{item.product.price} × {item.quantity} = ₹{item.product.price * item.quantity}
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                        className="p-1 rounded bg-stone-100 hover:bg-stone-200 text-slate-600"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-5 text-center font-bold font-mono">{item.quantity}</span>
                      <button
                        onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                        className="p-1 rounded bg-stone-100 hover:bg-stone-200 text-slate-600"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-2 pt-2 border-t border-stone-100 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span className="font-mono font-bold">₹{cartTotal}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Local Delivery / Packing</span>
                  <span className="font-mono text-emerald-600 font-bold">Free (Community)</span>
                </div>
                <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-2 border-t border-stone-100">
                  <span>Total Due</span>
                  <span className="font-mono text-teal-900">₹{cartTotal}</span>
                </div>
              </div>

              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-[11px] text-emerald-900 flex items-start gap-2">
                <Heart className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  This order subsidizes approximately{' '}
                  <strong>{Math.max(1, Math.round(cartTotal / 40))} free nutritious meals</strong>{' '}
                  for elderly seniors in Kumbakonam.
                </span>
              </div>

              <button
                onClick={() => setIsCheckoutOpen(true)}
                className="w-full py-3 bg-teal-800 hover:bg-teal-900 text-white rounded-2xl text-xs font-bold shadow-md transition-transform hover:scale-[1.02] flex items-center justify-center gap-2"
              >
                Proceed to Checkout (₹{cartTotal})
              </button>
            </div>
          )}
        </div>
      )}

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">Customer Order Records</h3>

          <div className="divide-y divide-stone-100 text-xs">
            {orders.map((order) => (
              <div key={order.id} className="py-4 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="font-mono font-bold text-teal-900">{order.orderNumber}</span>
                    <span className="text-slate-400 mx-2">·</span>
                    <span className="font-bold text-slate-800">{order.customerName}</span>
                    <span className="text-slate-500 ml-1">({order.customerPhone})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                        order.status === 'Delivered'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {order.status}
                    </span>
                    <span className="font-mono font-bold text-slate-900">₹{order.totalAmount}</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between text-slate-500 text-[11px] gap-2">
                  <span>
                    Items:{' '}
                    {order.items.map((i) => `${i.productName} (x${i.quantity})`).join(', ')}
                  </span>
                  <span>{order.createdAt}</span>
                </div>

                <div className="text-[11px] text-emerald-800 bg-emerald-50/70 p-2 rounded-xl border border-emerald-100 flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{order.impactNote}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Market Admin Tab */}
      {activeTab === 'admin' && (
        <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Market Order Operations</h3>
              <p className="text-xs text-slate-500">
                Update order statuses & track community revenue allocation
              </p>
            </div>
            <div className="text-xs font-mono font-bold text-teal-900 bg-teal-50 px-3 py-1.5 rounded-xl border border-teal-200">
              Total Market Revenue: ₹8,450
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-stone-50 text-slate-500 uppercase font-semibold text-[10px] border-b border-stone-200">
                <tr>
                  <th className="py-2.5 px-3">Order</th>
                  <th className="py-2.5 px-3">Customer</th>
                  <th className="py-2.5 px-3">Items</th>
                  <th className="py-2.5 px-3">Total</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Change Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {orders.map((o) => (
                  <tr key={o.id}>
                    <td className="py-3 px-3 font-mono font-bold text-slate-800">{o.orderNumber}</td>
                    <td className="py-3 px-3">
                      <span className="font-bold text-slate-900 block">{o.customerName}</span>
                      <span className="text-[11px] text-slate-500">{o.customerPhone}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-700">{o.items.length} item(s)</td>
                    <td className="py-3 px-3 font-mono font-bold text-slate-900">₹{o.totalAmount}</td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded-md font-bold text-[10px] bg-stone-100 text-slate-800">
                        {o.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <select
                        value={o.status}
                        onChange={(e) => updateOrderStatus(o.id, e.target.value as any)}
                        className="p-1 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                      >
                        <option value="Confirmed">Confirmed</option>
                        <option value="Preparing">Preparing</option>
                        <option value="Out for Delivery">Out for Delivery</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 my-8 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="text-base font-bold text-slate-900">
                Complete Community Market Order
              </h3>
              <button
                onClick={() => setIsCheckoutOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCheckoutSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Your Full Name</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Phone Number (WhatsApp)</label>
                <input
                  type="tel"
                  required
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Delivery Address in Kumbakonam</label>
                <textarea
                  rows={2}
                  required
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Delivery Type</label>
                  <select
                    value={deliveryType}
                    onChange={(e) => setDeliveryType(e.target.value as any)}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  >
                    <option value="delivery">Doorstep Delivery</option>
                    <option value="pickup">Pickup at Central Hub</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value as any)}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  >
                    <option value="UPI / GPay">UPI / GPay (Instant)</option>
                    <option value="Cash on Delivery">Cash on Delivery</option>
                    <option value="Card">Debit / Credit Card</option>
                  </select>
                </div>
              </div>

              {/* Impact Callout */}
              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-[11px] text-emerald-900 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 text-emerald-600" />
                  <span>SDG 2 Zero Hunger Contribution</span>
                </div>
                <p>
                  Proceeds from your order amount of <strong>₹{cartTotal}</strong> will directly
                  sponsor hot nutritious rice & sambar meals for Kumbakonam elderly beneficiaries.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCheckoutOpen(false)}
                  className="py-2.5 px-4 bg-stone-100 hover:bg-stone-200 text-slate-700 rounded-xl font-medium"
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="py-2.5 px-5 bg-teal-800 hover:bg-teal-900 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-sm"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Confirm Order (₹{cartTotal})
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmed Order Success Popover */}
      {confirmedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl border border-stone-200 animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto text-2xl">
              🎉
            </div>
            <div>
              <span className="text-xs font-mono font-bold text-teal-800 uppercase tracking-wider block">
                {confirmedOrder.orderNumber}
              </span>
              <h3 className="text-xl font-black text-slate-900 mt-1">Thank you for your order!</h3>
              <p className="text-xs text-slate-500 mt-1">
                Your order is confirmed and will be dispatched to {confirmedOrder.deliveryAddress}.
              </p>
            </div>

            <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-900 font-semibold">
              ❤️ {confirmedOrder.impactNote}
            </div>

            <button
              onClick={() => {
                setConfirmedOrder(null);
                setActiveTab('orders');
              }}
              className="w-full py-3 bg-teal-800 hover:bg-teal-900 text-white rounded-xl text-xs font-bold"
            >
              View Order in History
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
