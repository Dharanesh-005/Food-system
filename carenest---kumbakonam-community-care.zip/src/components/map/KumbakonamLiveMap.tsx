import React, { useState } from 'react';
import { useCareNest } from '../../context/CareNestContext';
import { Beneficiary, AreaName } from '../../types';
import {
  MapPin,
  Navigation,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  ShieldCheck,
  AlertTriangle,
  User,
  Phone,
  Clock,
  Layers,
  Sparkles,
} from 'lucide-react';

interface KumbakonamLiveMapProps {
  onSelectBeneficiary?: (beneficiary: Beneficiary) => void;
  focusedBeneficiaryId?: string | null;
  compact?: boolean;
}

export const KumbakonamLiveMap: React.FC<KumbakonamLiveMapProps> = ({
  onSelectBeneficiary,
  focusedBeneficiaryId,
  compact = false,
}) => {
  const {
    beneficiaries,
    deliveries,
    volunteers,
    emergencies,
    selectedAreaFilter,
    setSelectedAreaFilter,
    selectedStatusFilter,
    setSelectedStatusFilter,
    setSelectedBeneficiaryId,
  } = useCareNest();

  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [selectedPin, setSelectedPin] = useState<Beneficiary | null>(() => {
    return beneficiaries.find((b) => b.id === focusedBeneficiaryId) || null;
  });

  // Center bounding box for Kumbakonam and surrounding taluks
  // Lat range: 10.8800 to 11.0300 (~0.15 deg)
  // Lng range: 79.3100 to 79.4800 (~0.17 deg)
  const MIN_LAT = 10.88;
  const MAX_LAT = 11.03;
  const MIN_LNG = 79.31;
  const MAX_LNG = 79.48;

  const projectCoords = (lat: number, lng: number) => {
    // Mercator-like 2D bounding projection into SVG 0-1000 x 0-700
    const x = ((lng - MIN_LNG) / (MAX_LNG - MIN_LNG)) * 900 + 50;
    const y = ((MAX_LAT - lat) / (MAX_LAT - MIN_LAT)) * 580 + 60;
    return { x, y };
  };

  // Filter beneficiaries
  const filteredBeneficiaries = beneficiaries.filter((b) => {
    if (selectedAreaFilter !== 'All' && b.area !== selectedAreaFilter) {
      return false;
    }
    if (selectedStatusFilter === 'Critical') {
      return b.foodStatus === 'critical';
    }
    if (selectedStatusFilter === 'Low') {
      return b.foodStatus === 'low';
    }
    if (selectedStatusFilter === 'Emergency') {
      return b.foodStatus === 'emergency';
    }
    if (selectedStatusFilter === 'Delivered' || selectedStatusFilter === 'Sufficient') {
      return b.foodStatus === 'sufficient';
    }
    return true;
  });

  const getMarkerColor = (status: Beneficiary['foodStatus']) => {
    switch (status) {
      case 'emergency':
        return {
          bg: 'bg-purple-600',
          text: 'text-purple-600',
          border: 'border-purple-600',
          fill: '#9333ea',
          pulse: 'emergency-pulse',
        };
      case 'critical':
        return {
          bg: 'bg-red-500',
          text: 'text-red-500',
          border: 'border-red-500',
          fill: '#ef4444',
          pulse: 'animate-pulse',
        };
      case 'low':
        return {
          bg: 'bg-amber-500',
          text: 'text-amber-500',
          border: 'border-amber-500',
          fill: '#f59e0b',
          pulse: '',
        };
      case 'sufficient':
      default:
        return {
          bg: 'bg-emerald-500',
          text: 'text-emerald-500',
          border: 'border-emerald-500',
          fill: '#10b981',
          pulse: '',
        };
    }
  };

  const handleMarkerClick = (b: Beneficiary) => {
    setSelectedPin(b);
    if (onSelectBeneficiary) {
      onSelectBeneficiary(b);
    }
  };

  const areasList: Array<AreaName | 'All'> = [
    'All',
    'Kumbakonam Town',
    'Darasuram',
    'Swamimalai',
    'Patteeswaram',
    'Nachiyarkoil',
    'Thiruvidaimarudur',
    'Valangaiman',
    'Koranattukaruppur',
    'Ullur',
    'Cholapuram',
  ];

  return (
    <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden flex flex-col">
      {/* Header bar */}
      <div className="p-4 md:px-6 md:py-4 border-b border-stone-100 flex flex-wrap items-center justify-between gap-3 bg-stone-50/70">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-teal-50 text-teal-700">
              <MapPin className="w-5 h-5 text-teal-700" />
            </span>
            <div>
              <h2 className="text-base md:text-lg font-bold text-slate-900 tracking-tight">
                Live Assistance Map
              </h2>
              <p className="text-xs text-slate-500">
                Kumbakonam Community Network · Real-time GPS & Food Stock Radar
              </p>
            </div>
          </div>
        </div>

        {/* Legend / Status Indicators */}
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span>Sufficient</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <span>Low</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
            <span className="font-semibold text-red-600">Critical</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-600 animate-pulse"></span>
            <span className="font-semibold text-purple-700">Emergency</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
            <span>Volunteer Active</span>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="px-4 md:px-6 py-2.5 bg-white border-b border-stone-100 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Status Filter Buttons */}
        <div className="flex items-center gap-1 p-0.5 bg-stone-100 rounded-lg overflow-x-auto max-w-full">
          {['All', 'Critical', 'Low', 'Emergency', 'Sufficient'].map((status) => (
            <button
              key={status}
              onClick={() => setSelectedStatusFilter(status)}
              className={`px-3 py-1 rounded-md font-medium transition-colors whitespace-nowrap ${
                selectedStatusFilter === status
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {status}
            </button>
          ))}
        </div>

        {/* Area Filter Select */}
        <div className="flex items-center gap-2">
          <span className="text-slate-400">Area:</span>
          <select
            value={selectedAreaFilter}
            onChange={(e) => setSelectedAreaFilter(e.target.value as any)}
            className="text-xs bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-1.5 text-slate-700 font-medium focus:outline-teal-600"
          >
            {areasList.map((area) => (
              <option key={area} value={area}>
                {area === 'All' ? 'All Areas (Kumbakonam Region)' : area}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Interactive Map Canvas Container */}
      <div className="relative w-full aspect-16/10 md:aspect-21/9 min-h-[380px] md:min-h-[460px] bg-[#f8f9fa] overflow-hidden select-none">
        {/* SVG Base Map */}
        <svg
          viewBox="0 0 1000 700"
          className="w-full h-full transition-transform duration-300 ease-out"
          style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'center center' }}
        >
          {/* Defs for gradients & patterns */}
          <defs>
            <linearGradient id="cauveryRiver" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#bfdbfe" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#93c5fd" stopOpacity="0.9" />
            </linearGradient>
            <pattern id="gridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e5e7eb" strokeWidth="0.75" />
            </pattern>
          </defs>

          {/* Background Grid */}
          <rect width="1000" height="700" fill="url(#gridPattern)" />

          {/* Cauvery & Arasalar River Paths (Defining Geography of Kumbakonam) */}
          <path
            d="M 20,200 Q 200,240 380,210 T 650,220 T 980,180"
            fill="none"
            stroke="url(#cauveryRiver)"
            strokeWidth="14"
            strokeLinecap="round"
          />
          <text x="750" y="165" fill="#3b82f6" fontSize="11" fontWeight="600" opacity="0.6">
            Cauvery River
          </text>

          <path
            d="M 40,430 Q 280,450 480,400 T 780,390 T 980,410"
            fill="none"
            stroke="url(#cauveryRiver)"
            strokeWidth="10"
            strokeLinecap="round"
          />
          <text x="820" y="380" fill="#3b82f6" fontSize="10" fontWeight="600" opacity="0.6">
            Arasalar River
          </text>

          {/* Major Roads (NH 36, SH 64 connecting Darasuram, Kumbakonam Town, Thiruvidaimarudur) */}
          <path
            d="M 50,320 L 260,330 L 460,310 L 680,270 L 950,230"
            fill="none"
            stroke="#cbd5e1"
            strokeWidth="6"
            strokeLinecap="round"
          />
          <path
            d="M 460,100 L 460,310 L 410,500 L 380,650"
            fill="none"
            stroke="#cbd5e1"
            strokeWidth="5"
            strokeLinecap="round"
          />
          <path
            d="M 260,330 L 320,520"
            fill="none"
            stroke="#e2e8f0"
            strokeWidth="3.5"
            strokeDasharray="4 4"
          />
          <path
            d="M 460,310 L 680,490"
            fill="none"
            stroke="#e2e8f0"
            strokeWidth="3.5"
            strokeDasharray="4 4"
          />

          {/* Mahamaham Tank Center Landmark */}
          <circle cx="480" cy="300" r="16" fill="#60a5fa" fillOpacity="0.4" stroke="#2563eb" strokeWidth="1.5" />
          <text x="480" y="325" fill="#1e40af" fontSize="9" fontWeight="600" textAnchor="middle">
            Mahamaham Tank
          </text>

          {/* Area Region Labels */}
          <g opacity="0.75">
            <text x="495" y="275" fill="#0f172a" fontSize="14" fontWeight="800">
              Kumbakonam Town
            </text>
            <text x="245" y="315" fill="#475569" fontSize="12" fontWeight="700">
              Darasuram
            </text>
            <text x="110" y="335" fill="#475569" fontSize="12" fontWeight="700">
              Swamimalai
            </text>
            <text x="320" y="555" fill="#475569" fontSize="12" fontWeight="700">
              Patteeswaram
            </text>
            <text x="710" y="535" fill="#475569" fontSize="12" fontWeight="700">
              Nachiyarkoil
            </text>
            <text x="760" y="240" fill="#475569" fontSize="12" fontWeight="700">
              Thiruvidaimarudur
            </text>
            <text x="440" y="620" fill="#475569" fontSize="12" fontWeight="700">
              Valangaiman
            </text>
            <text x="420" y="160" fill="#475569" fontSize="12" fontWeight="700">
              Koranattukaruppur
            </text>
            <text x="590" y="120" fill="#475569" fontSize="12" fontWeight="700">
              Cholapuram
            </text>
            <text x="520" y="470" fill="#475569" fontSize="12" fontWeight="700">
              Ullur
            </text>
          </g>

          {/* Central NGO Hub Marker */}
          <g transform="translate(460, 310)">
            <circle cx="0" cy="0" r="18" fill="#0f766e" fillOpacity="0.2" />
            <circle cx="0" cy="0" r="10" fill="#0f766e" />
            <text x="0" y="4" fill="white" fontSize="9" fontWeight="bold" textAnchor="middle">
              CN
            </text>
            <text x="0" y="24" fill="#0f766e" fontSize="10" fontWeight="bold" textAnchor="middle">
              CareNest Central Hub
            </text>
          </g>

          {/* Active Delivery Routes (Volunteer -> Route -> Beneficiary) */}
          {deliveries
            .filter((d) => d.status === 'Out for Delivery' || d.status === 'Assigned')
            .map((del) => {
              const startPt = projectCoords(del.currentVolunteerCoords.lat, del.currentVolunteerCoords.lng);
              const destPt = projectCoords(del.destCoords.lat, del.destCoords.lng);

              return (
                <g key={del.id}>
                  {/* Route Line */}
                  <line
                    x1={startPt.x}
                    y1={startPt.y}
                    x2={destPt.x}
                    y2={destPt.y}
                    stroke="#0284c7"
                    strokeWidth="3"
                    strokeDasharray="6 4"
                    strokeLinecap="round"
                    className="animate-pulse"
                  />
                  {/* Moving Volunteer Icon */}
                  <circle cx={startPt.x} cy={startPt.y} r="8" fill="#0284c7" stroke="white" strokeWidth="2" />
                  <text
                    x={startPt.x}
                    y={startPt.y - 12}
                    fill="#0369a1"
                    fontSize="9"
                    fontWeight="700"
                    textAnchor="middle"
                  >
                    🚚 {del.volunteerName.split(' ')[0]} ({del.etaMinutes}m)
                  </text>
                </g>
              );
            })}

          {/* Beneficiary Pins */}
          {filteredBeneficiaries.map((b) => {
            const { x, y } = projectCoords(b.coords.lat, b.coords.lng);
            const style = getMarkerColor(b.foodStatus);
            const isSelected = selectedPin?.id === b.id;

            return (
              <g
                key={b.id}
                transform={`translate(${x}, ${y})`}
                className="cursor-pointer group"
                onClick={() => handleMarkerClick(b)}
              >
                {/* Pulse Ring for Emergency / Critical */}
                {(b.foodStatus === 'emergency' || b.foodStatus === 'critical') && (
                  <circle
                    cx="0"
                    cy="0"
                    r={isSelected ? '22' : '17'}
                    fill={style.fill}
                    opacity="0.25"
                    className={style.pulse}
                  />
                )}

                {/* Outer halo if selected */}
                {isSelected && (
                  <circle cx="0" cy="0" r="18" fill="none" stroke="#0f172a" strokeWidth="2.5" />
                )}

                {/* Pin Circle */}
                <circle
                  cx="0"
                  cy="0"
                  r={isSelected ? '12' : '9'}
                  fill={style.fill}
                  stroke="white"
                  strokeWidth="2"
                  className="transition-all duration-200 group-hover:scale-125"
                />

                {/* Inner Icon / Dot */}
                <circle cx="0" cy="0" r="3" fill="white" />

                {/* Mini Label */}
                <text
                  x="0"
                  y={isSelected ? '-16' : '-13'}
                  fill="#1e293b"
                  fontSize={isSelected ? '11' : '9'}
                  fontWeight={isSelected ? '800' : '600'}
                  textAnchor="middle"
                  className="transition-all select-none drop-shadow-xs"
                >
                  {b.name}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Map Control Buttons (Zoom / Reset) */}
        <div className="absolute right-4 bottom-4 flex flex-col gap-2 bg-white/95 backdrop-blur-xs p-1 rounded-xl shadow-md border border-stone-200">
          <button
            onClick={() => setZoomLevel((z) => Math.min(z + 0.25, 2.2))}
            title="Zoom In"
            className="p-2 text-slate-700 hover:text-teal-700 hover:bg-stone-100 rounded-lg transition-colors"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoomLevel((z) => Math.max(z - 0.25, 0.9))}
            title="Zoom Out"
            className="p-2 text-slate-700 hover:text-teal-700 hover:bg-stone-100 rounded-lg transition-colors"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setZoomLevel(1);
              setSelectedPin(null);
            }}
            title="Reset Map View"
            className="p-2 text-slate-700 hover:text-teal-700 hover:bg-stone-100 rounded-lg transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Floating Beneficiary Quick Card upon marker click */}
        {selectedPin && (
          <div className="absolute left-4 top-4 max-w-xs md:max-w-sm w-full bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-stone-200 animate-in fade-in slide-in-from-top-2 duration-200 z-20">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-11 h-11 rounded-full bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-sm border-2 border-white shadow-xs shrink-0 overflow-hidden">
                  {selectedPin.profilePhotoUrl ? (
                    <img
                      src={selectedPin.profilePhotoUrl}
                      alt={selectedPin.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span>{selectedPin.name.slice(0, 2).toUpperCase()}</span>
                  )}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 leading-tight">
                    {selectedPin.name}
                  </h4>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                    <span>{selectedPin.age} yrs</span>
                    <span>·</span>
                    <span className="font-mono text-slate-600">{selectedPin.code}</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedPin(null)}
                className="text-slate-400 hover:text-slate-700 p-1 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="mt-3 pt-3 border-t border-stone-100 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Location Area</span>
                <span className="font-semibold text-slate-800">📍 {selectedPin.area}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Food Remaining</span>
                <span
                  className={`font-semibold ${
                    selectedPin.foodStatus === 'critical'
                      ? 'text-red-600 font-mono'
                      : selectedPin.foodStatus === 'low'
                      ? 'text-amber-600 font-mono'
                      : 'text-emerald-600 font-mono'
                  }`}
                >
                  {selectedPin.currentStockKg} kg / {selectedPin.requiredStockKg} kg
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Environment</span>
                <span className="text-slate-700 font-mono">
                  🌡️ {selectedPin.ambientTemp}°C · 💧 {selectedPin.ambientHumidity}%
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Today's Meals</span>
                <span className="text-slate-700">
                  {selectedPin.mealStatus.breakfast === 'completed' ? 'B ✅' : 'B ⏳'} ·{' '}
                  {selectedPin.mealStatus.lunch === 'completed' ? 'L ✅' : 'L ⏳'} ·{' '}
                  {selectedPin.mealStatus.dinner === 'completed' ? 'D ✅' : 'D ⏳'}
                </span>
              </div>
            </div>

            <div className="mt-3.5 pt-2 flex gap-2">
              <button
                onClick={() => {
                  setSelectedBeneficiaryId(selectedPin.id);
                  if (onSelectBeneficiary) onSelectBeneficiary(selectedPin);
                }}
                className="flex-1 py-1.5 px-3 bg-teal-700 hover:bg-teal-800 text-white rounded-lg text-xs font-semibold text-center transition-colors"
              >
                Open Full Profile
              </button>
              <a
                href={`tel:${selectedPin.phone}`}
                className="py-1.5 px-3 bg-stone-100 hover:bg-stone-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
              >
                <Phone className="w-3.5 h-3.5" /> Call
              </a>
            </div>
          </div>
        )}

        {/* Live GPS Active Status Pill */}
        <div className="absolute left-4 bottom-4 bg-white/95 backdrop-blur-xs px-3 py-1.5 rounded-lg shadow-sm border border-stone-200 flex items-center gap-2 text-xs text-slate-600">
          <span className="w-2 h-2 rounded-full bg-teal-500 animate-ping"></span>
          <span className="font-medium">Kumbakonam Region GPS Sync Active</span>
          <span className="text-slate-400">·</span>
          <span className="font-mono text-slate-500">{filteredBeneficiaries.length} records</span>
        </div>
      </div>
    </div>
  );
};
