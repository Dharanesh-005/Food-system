import React, { useState } from 'react';
import { useCareNest } from '../../context/CareNestContext';
import { Delivery, Volunteer } from '../../types';
import { PhotoUploadModal } from '../common/PhotoUploadModal';
import {
  Truck,
  MapPin,
  Phone,
  CheckCircle2,
  Camera,
  Navigation,
  Clock,
  ShieldCheck,
  Award,
} from 'lucide-react';

export const VolunteerPortal: React.FC = () => {
  const {
    volunteers,
    deliveries,
    updateDeliveryStatus,
  } = useCareNest();

  // Current active volunteer
  const [currentVolId, setCurrentVolId] = useState(volunteers[0]?.id || '');
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);
  const [activeDeliveryId, setActiveDeliveryId] = useState<string | null>(null);

  const volunteer = volunteers.find((v) => v.id === currentVolId) || volunteers[0];
  const assignedDeliveries = deliveries.filter(
    (d) => d.volunteerId === volunteer?.id && d.status !== 'Delivered'
  );
  const completedDeliveries = deliveries.filter(
    (d) => d.volunteerId === volunteer?.id && d.status === 'Delivered'
  );

  const handlePhotoCaptured = (photoUrl: string) => {
    if (activeDeliveryId) {
      updateDeliveryStatus(activeDeliveryId, 'Delivered', photoUrl);
      setIsPhotoModalOpen(false);
      setActiveDeliveryId(null);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-20">
      {/* Volunteer Header & Switcher */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-800 border border-blue-200 inline-flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-blue-600" />
              Field Volunteer Delivery Portal
            </span>
          </div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            Welcome, {volunteer?.name} 👋
          </h2>
          <p className="text-xs text-slate-500">
            Assigned Service Area: <strong>{volunteer?.serviceArea}</strong> · Vehicle:{' '}
            {volunteer?.vehicleType}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Switch Volunteer:</span>
          <select
            value={currentVolId}
            onChange={(e) => setCurrentVolId(e.target.value)}
            className="text-xs font-bold text-slate-800 bg-stone-50 border border-stone-200 rounded-xl px-2.5 py-1.5"
          >
            {volunteers.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name} ({v.serviceArea})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Active Runs */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <span>Active Assigned Runs</span>
          <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 text-xs font-mono font-bold">
            {assignedDeliveries.length}
          </span>
        </h3>

        {assignedDeliveries.length > 0 ? (
          <div className="space-y-4">
            {assignedDeliveries.map((del) => (
              <div
                key={del.id}
                className="bg-white rounded-3xl border-2 border-teal-600/60 p-6 shadow-sm space-y-4"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-xs font-mono font-bold text-teal-800 uppercase block">
                      Run #{del.id} · ETA ~{del.etaMinutes} mins
                    </span>
                    <h4 className="text-lg font-black text-slate-900 mt-0.5">
                      Deliver to {del.beneficiaryName}
                    </h4>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {del.area}
                    </p>
                  </div>

                  <span className="px-3 py-1 rounded-xl text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200">
                    {del.status}
                  </span>
                </div>

                <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-100 text-xs space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Food Items:</span>
                    <span className="font-bold text-slate-800">{del.foodItems}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Contact Beneficiary:</span>
                    <a
                      href={`tel:${del.beneficiaryPhone}`}
                      className="text-teal-800 font-bold hover:underline flex items-center gap-1"
                    >
                      <Phone className="w-3 h-3" /> {del.beneficiaryPhone}
                    </a>
                  </div>
                </div>

                {/* Workflow Buttons */}
                <div className="flex flex-wrap items-center gap-2.5 pt-2 border-t border-stone-100">
                  {del.status === 'Assigned' && (
                    <button
                      onClick={() => updateDeliveryStatus(del.id, 'Accepted')}
                      className="py-2.5 px-4 bg-teal-800 hover:bg-teal-900 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                    >
                      Accept Assignment
                    </button>
                  )}

                  {del.status === 'Accepted' && (
                    <button
                      onClick={() => updateDeliveryStatus(del.id, 'Out for Delivery')}
                      className="py-2.5 px-4 bg-teal-800 hover:bg-teal-900 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
                    >
                      <Truck className="w-4 h-4" /> Start Delivery (Out for Delivery)
                    </button>
                  )}

                  {del.status === 'Out for Delivery' && (
                    <button
                      onClick={() => updateDeliveryStatus(del.id, 'Arrived')}
                      className="py-2.5 px-4 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
                    >
                      <Navigation className="w-4 h-4" /> Mark Arrived at Destination
                    </button>
                  )}

                  {del.status === 'Arrived' && (
                    <button
                      onClick={() => {
                        setActiveDeliveryId(del.id);
                        setIsPhotoModalOpen(true);
                      }}
                      className="py-2.5 px-5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition-colors flex items-center gap-1.5"
                    >
                      <Camera className="w-4 h-4" /> Capture Photo Proof & Complete
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-3xl border border-stone-200 p-8 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
            <h4 className="text-base font-bold text-slate-800">No Pending Delivery Runs</h4>
            <p className="text-xs text-slate-400">
              You are available for new dispatches in {volunteer?.serviceArea}.
            </p>
          </div>
        )}
      </div>

      {/* Completed History */}
      {completedDeliveries.length > 0 && (
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            Completed Runs Today ({completedDeliveries.length})
          </h3>

          <div className="divide-y divide-stone-100 text-xs">
            {completedDeliveries.map((del) => (
              <div key={del.id} className="py-3 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-900">{del.beneficiaryName}</h4>
                  <p className="text-slate-500 text-[11px]">
                    {del.area} · {del.foodItems}
                  </p>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-md font-bold text-[10px]">
                    Delivered
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                    {del.deliveryTimestamp || del.completedAt || '11:42 AM'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Photo Proof Modal */}
      <PhotoUploadModal
        isOpen={isPhotoModalOpen}
        onClose={() => setIsPhotoModalOpen(false)}
        onPhotoSelected={handlePhotoCaptured}
        title="Delivery Verification Photo"
        description="Photograph meal delivery to beneficiary for zero-hunger audit."
        consentNotice="Delivery photos are securely stored to verify zero-hunger impact and food recipient safety."
      />
    </div>
  );
};
