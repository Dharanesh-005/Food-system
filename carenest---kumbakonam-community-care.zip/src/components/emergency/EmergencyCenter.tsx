import React, { useState } from 'react';
import { useCareNest } from '../../context/CareNestContext';
import { EmergencyAlert, Beneficiary } from '../../types';
import {
  AlertTriangle,
  Phone,
  MapPin,
  Clock,
  ShieldCheck,
  UserCheck,
  CheckCircle2,
  Navigation,
  Activity,
  AlertCircle,
} from 'lucide-react';

interface EmergencyCenterProps {
  onOpenBeneficiary: (b: Beneficiary) => void;
}

export const EmergencyCenter: React.FC<EmergencyCenterProps> = ({ onOpenBeneficiary }) => {
  const {
    emergencies,
    volunteers,
    beneficiaries,
    resolveEmergency,
    assignVolunteerToEmergency,
    triggerEmergency,
    addToast,
  } = useCareNest();

  const [isTriggerModalOpen, setIsTriggerModalOpen] = useState(false);
  const [selectedBenId, setSelectedBenId] = useState(beneficiaries[0]?.id || '');
  const [emergencyReason, setEmergencyReason] = useState('Severe hunger / Acute weakness / Fall reported');

  const activeAlerts = emergencies.filter((e) => e.status !== 'Resolved');
  const resolvedAlerts = emergencies.filter((e) => e.status === 'Resolved');

  const handleManualTrigger = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBenId) return;

    const ben = beneficiaries.find((b) => b.id === selectedBenId);
    if (!ben) return;

    triggerEmergency(ben.id, ben.coords, emergencyReason);
    setIsTriggerModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-red-50 p-6 rounded-3xl border border-red-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-red-600 text-white inline-flex items-center gap-1.5 emergency-pulse">
              <AlertTriangle className="w-3.5 h-3.5" />
              Priority Rapid Response
            </span>
          </div>
          <h2 className="text-xl font-black text-red-950 tracking-tight">
            Emergency Care & SOS Response Center
          </h2>
          <p className="text-xs text-red-800/80 mt-0.5">
            Real-time critical food and medical distress escalations in the Kumbakonam cluster
          </p>
        </div>

        <button
          onClick={() => setIsTriggerModalOpen(true)}
          className="px-5 py-3 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-xs font-bold shadow-md hover:shadow-lg transition-all flex items-center gap-2"
        >
          <AlertTriangle className="w-4 h-4" />
          🚨 Trigger Emergency Dispatch
        </button>
      </div>

      {/* Active Alerts Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span>Active Distress Alerts</span>
            <span className="px-2 py-0.5 rounded-md bg-red-100 text-red-700 text-xs font-bold font-mono">
              {activeAlerts.length}
            </span>
          </h3>
          <span className="text-xs text-slate-400">Average response time: 6.4 minutes</span>
        </div>

        {activeAlerts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeAlerts.map((emg) => {
              const ben = beneficiaries.find((b) => b.id === emg.beneficiaryId);

              return (
                <div
                  key={emg.id}
                  className="bg-white rounded-3xl border-2 border-red-300 p-6 shadow-md hover:shadow-lg transition-all flex flex-col justify-between space-y-4 relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-2 h-full bg-red-500" />

                  {/* Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-700 flex items-center justify-center font-bold text-lg emergency-pulse shrink-0">
                        🚨
                      </div>
                      <div>
                        <h4 className="text-base font-bold text-slate-900 leading-tight">
                          {emg.beneficiaryName}
                        </h4>
                        <p className="text-xs text-slate-500">
                          {emg.age} years · 📍 {emg.area}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-mono font-bold text-red-600 block">
                        {emg.time}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-red-50 text-red-700 border border-red-200 uppercase">
                        {emg.status}
                      </span>
                    </div>
                  </div>

                  {/* Emergency Description & Notes */}
                  <div className="p-3 bg-red-50/50 rounded-2xl border border-red-100 text-xs text-red-950 space-y-1">
                    <span className="font-bold block">Distress Reason:</span>
                    <p className="leading-relaxed">{emg.notes}</p>
                    {emg.assignedVolunteerName && (
                      <div className="pt-1.5 text-xs text-teal-900 font-semibold flex items-center gap-1.5 border-t border-red-200/60 mt-2">
                        <UserCheck className="w-3.5 h-3.5 text-teal-700" />
                        <span>Dispatched to Volunteer: {emg.assignedVolunteerName}</span>
                      </div>
                    )}
                  </div>

                  {/* Action Buttons: View Location, Contact, Assign Volunteer, Resolve */}
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-stone-100">
                    {ben && (
                      <button
                        onClick={() => onOpenBeneficiary(ben)}
                        className="py-2 px-3 bg-stone-100 hover:bg-stone-200 text-slate-800 font-semibold text-xs rounded-xl transition-colors flex items-center gap-1"
                      >
                        <MapPin className="w-3.5 h-3.5" /> View Location
                      </button>
                    )}

                    <a
                      href={`tel:${emg.phone}`}
                      className="py-2 px-3 bg-stone-100 hover:bg-stone-200 text-slate-800 font-semibold text-xs rounded-xl transition-colors flex items-center gap-1"
                    >
                      <Phone className="w-3.5 h-3.5" /> Call ({emg.phone})
                    </a>

                    {!emg.assignedVolunteerId ? (
                      <div className="flex items-center gap-1 flex-1">
                        <select
                          id={`emg-vol-${emg.id}`}
                          className="p-2 bg-stone-50 border border-stone-200 rounded-xl text-xs flex-1 font-medium"
                          defaultValue=""
                        >
                          <option value="" disabled>
                            Assign Volunteer
                          </option>
                          {volunteers.map((v) => (
                            <option key={v.id} value={v.id}>
                              {v.name} ({v.serviceArea})
                            </option>
                          ))}
                        </select>
                        <button
                          onClick={() => {
                            const sel = document.getElementById(
                              `emg-vol-${emg.id}`
                            ) as HTMLSelectElement;
                            if (sel && sel.value) {
                              assignVolunteerToEmergency(emg.id, sel.value);
                            } else {
                              addToast('Select Volunteer', 'Please select a volunteer first.', 'warning');
                            }
                          }}
                          className="py-2 px-3 bg-teal-800 hover:bg-teal-900 text-white rounded-xl font-bold text-xs shadow-xs transition-colors whitespace-nowrap"
                        >
                          Dispatch
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => resolveEmergency(emg.id)}
                        className="py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-xs transition-colors flex items-center gap-1 ml-auto"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" /> Mark Resolved
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-3xl border border-stone-200 p-8 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
            <h4 className="text-base font-bold text-slate-800">All Emergency Signals Clear</h4>
            <p className="text-xs text-slate-400">
              No active distress calls at this moment in the Kumbakonam cluster.
            </p>
          </div>
        )}
      </div>

      {/* Resolved History */}
      {resolvedAlerts.length > 0 && (
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            Resolved Emergency Incidents ({resolvedAlerts.length})
          </h3>

          <div className="divide-y divide-stone-100 text-xs">
            {resolvedAlerts.map((emg) => (
              <div key={emg.id} className="py-3 flex items-center justify-between gap-4">
                <div>
                  <span className="font-bold text-slate-800">{emg.beneficiaryName}</span>
                  <span className="text-slate-400 mx-1.5">·</span>
                  <span className="text-slate-500">{emg.area}</span>
                  <p className="text-slate-500 text-[11px] mt-0.5">{emg.notes}</p>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                    Resolved
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                    {emg.time}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Trigger Modal */}
      {isTriggerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border-2 border-red-400 animate-in fade-in">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <h3 className="text-base font-bold text-slate-900">Raise Priority Emergency SOS</h3>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              This triggers a high-priority alert on the live dashboard and notifies nearby volunteers.
            </p>

            <form onSubmit={handleManualTrigger} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Select Vulnerable Senior
                </label>
                <select
                  value={selectedBenId}
                  onChange={(e) => setSelectedBenId(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                >
                  {beneficiaries.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.age} yrs · {b.area})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Reported Emergency Condition
                </label>
                <textarea
                  rows={3}
                  required
                  value={emergencyReason}
                  onChange={(e) => setEmergencyReason(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsTriggerModalOpen(false)}
                  className="py-2.5 px-4 bg-stone-100 hover:bg-stone-200 text-slate-700 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="py-2.5 px-5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold"
                >
                  Confirm Emergency Broadcast
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
